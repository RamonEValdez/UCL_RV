import Foundation
// 1. Introduzca un número entero
print("Introduce un número entero:")
// 2. Leer número ingresado
if let entradaUsuario = readLine() {
    // 3. Convertir la entrada a un número entero
    if let numero = Int(entradaUsuario) {
        // 4. Valida si el número ingresado es par o impar
        if numero % 2 == 0 {
            print("El número \(numero) es par.")
        } else {
            print("El número \(numero) es impar.")
        }
    } else {
        // Número no válido (no entero)    
        print("Error: Número no válido.")
    }
} 