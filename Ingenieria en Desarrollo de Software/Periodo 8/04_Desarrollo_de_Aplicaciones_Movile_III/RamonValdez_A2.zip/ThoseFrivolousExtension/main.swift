import Foundation

// Define la estructura de un producto con nombre, cantidad y precio.
struct Product {
    var nombre: String
    var cantidad: Int
    var precio: Double
}

// Gestiona la lógica del inventario, incluyendo añadir, listar y consultar productos.
class StoreInventory {
    // Array para almacenar todos los productos.
    private var products: [Product] = []

    // Función para registrar un nuevo producto o actualizar su cantidad si ya existe.
    func registerProduct() {
        print("\n--- Registrar un Artículo ---")
        print("Nombre del producto:")
        guard let name = readLine(), !name.isEmpty else {
            print("Error: El nombre del producto no puede estar vacío.")
            return
        }

        print("Cantidad de producto:")
        guard let quantityString = readLine(), let quantity = Int(quantityString), quantity >= 0 else {
            print("Error: Cantidad no válida. Por favor, introduce un número entero positivo o cero.")
            return
        }

        print("Precio del producto:")
        guard let priceString = readLine(), let price = Double(priceString), price >= 0 else {
            print("Error: Precio no válido. Por favor, introduce un número positivo.")
            return
        }

        // Buscar si el producto ya existe.
        if let index = products.firstIndex(where: { $0.nombre.lowercased() == name.lowercased() }) {
            // Si el producto existe, actualiza su cantidad.
            products[index].cantidad += quantity
            products[index].precio = price // También actualizamos el precio por si cambió.
            print("Cantidad de '\(name)' actualizada. Nueva cantidad: \(products[index].cantidad)")
        } else {
            // Si el producto no existe, lo añade como nuevo.
            let newProduct = Product(nombre: name, cantidad: quantity, precio: price)
            products.append(newProduct)
            print("Artículo '\(name)' registrado con éxito.")
        }
    }

    // Función para mostrar todos los productos registrados.
    func listAllProducts() {
        print("\n--- Lista de Artículos ---")
        if products.isEmpty {
            print("No hay artículos registrados en el inventario.")
            return
        }

        // Ordena los productos alfabéticamente por nombre para una mejor visualización.
        let sortedProducts = products.sorted { $0.nombre.lowercased() < $1.nombre.lowercased() }

        for product in sortedProducts {
            print("Nombre: \(product.nombre), Cantidad: \(product.cantidad), Precio: \(String(format: "%.2f", product.precio))")
        }
    }

    // Función para consultar un artículo por su nombre.
    func consultProductByName() {
        print("\n--- Consultar Artículo por Nombre ---")
        print("Introduce el nombre del artículo a consultar:")
        guard let searchName = readLine(), !searchName.isEmpty else {
            print("Error: El nombre del artículo no puede estar vacío.")
            return
        }

        // Busca el producto por nombre (ignorando mayúsculas/minúsculas).
        if let foundProduct = products.first(where: { $0.nombre.lowercased() == searchName.lowercased() }) {
            print("\n--- Información del Artículo ---")
            print("Nombre: \(foundProduct.nombre)")
            print("Cantidad: \(foundProduct.cantidad)")
            print("Precio: \(String(format: "%.2f", foundProduct.precio))")
        } else {
            print("El artículo '\(searchName)' no se encontró en el inventario.")
        }
    }

    // Función para consultar los artículos que tienen existencias (cantidad > 0).
    // Esta función se mantiene en la clase pero ya no está directamente en el menú principal.
    func checkStock() {
        print("\n--- Artículos en Existencia ---")
        let inStockProducts = products.filter { $0.cantidad > 0 }

        if inStockProducts.isEmpty {
            print("No hay artículos en existencia actualmente.")
            return
        }

        // Ordena los productos en existencia alfabéticamente por nombre.
        let sortedInStockProducts = inStockProducts.sorted { $0.nombre.lowercased() < $1.nombre.lowercased() }

        for product in sortedInStockProducts {
            print("Nombre: \(product.nombre), Cantidad: \(product.cantidad), Precio: \(String(format: "%.2f", product.precio))")
        }
    }
}

// Contiene el bucle principal del menú de la aplicación.
func runInventoryApp() {
    let inventory = StoreInventory()
    var running = true

    while running {
        print("\n--- Menú Principal del Inventario ---")
        print("1. Registrar un artículo")
        print("2. Ver la lista de artículos")
        print("3. Consultar artículo por nombre") // Opción 3 ahora es consultar por nombre
        print("4. Salir") // Opción de salir movida al 4
        print("Elige una opción:")

        // Lee la opción del usuario.
        if let choice = readLine() {
            switch choice {
            case "1":
                inventory.registerProduct()
            case "2":
                inventory.listAllProducts()
            case "3": // Manejo de la nueva opción 3
                inventory.consultProductByName()
            case "4": // Opción de salir
                running = false
                print("Saliendo de la aplicación. ¡Hasta pronto!")
            default:
                print("Opción no válida. Por favor, elige un número del 1 al 4.")
            }
        } else {
            print("Error al leer la entrada. Por favor, intenta de nuevo.")
        }
    }
}

// Inicia la aplicación de inventario.
runInventoryApp()