import Foundation

// Define la estructura para cada figura geométrica, encapsulando la lógica, para calcular su área. Esto hace el código más modular y fácil de mantener.

class Square {
    private var side: Double = 0.0

    init() {
        print("\n--- Calcular Área del Cuadrado ---")
        self.side = getInput(prompt: "Ingresa la longitud del lado:")
    }

    func calculateArea() -> Double {
        return side * side
    }

    func displayArea() {
        let area = calculateArea()
        print("El área del cuadrado es: \(String(format: "%.2f", area))")
    }
}

class Rectangle {
    private var base: Double = 0.0
    private var height: Double = 0.0

    init() {
        print("\n--- Calcular Área del Rectángulo ---")
        self.base = getInput(prompt: "Ingresa la longitud de la base:")
        self.height = getInput(prompt: "Ingresa la altura:")
    }

    func calculateArea() -> Double {
        return base * height
    }

    func displayArea() {
        let area = calculateArea()
        print("El área del rectángulo es: \(String(format: "%.2f", area))")
    }
}

class Triangle {
    private var base: Double = 0.0
    private var height: Double = 0.0

    init() {
        print("\n--- Calcular Área del Triángulo ---")
        self.base = getInput(prompt: "Ingresa la longitud de la base:")
        self.height = getInput(prompt: "Ingresa la altura:")
    }

    func calculateArea() -> Double {
        return (base * height) / 2
    }

    func displayArea() {
        let area = calculateArea()
        print("El área del triángulo es: \(String(format: "%.2f", area))")
    }
}

class Circle {
    private var radius: Double = 0.0

    init() {
        print("\n--- Calcular Área del Círculo ---")
        self.radius = getInput(prompt: "Ingresa el radio:")
    }

    func calculateArea() -> Double {
        return Double.pi * radius * radius
    }

    func displayArea() {
        let area = calculateArea()
        print("El área del círculo es: \(String(format: "%.2f", area))")
    }
}

// Estas funciones se encargan de la interacción con el usuario, como leer la entrada y validarla, lo que simplifica el código de las clases.

func getInput(prompt: String) -> Double {
    while true {
        print(prompt)
        guard let inputString = readLine(), let value = Double(inputString), value > 0 else {
            print("Error: Entrada no válida. Por favor, ingresa un número positivo.")
            continue
        }
        return value
    }
}

// AreaCalculatorApp gestiona el flujo principal de la aplicación, mostrando el menú y creando instancias de las clases de figuras según la elección del usuario. 
// Esto desacopla la lógica del menú de la lógica de cálculo de áreas.

class AreaCalculatorApp {
    func run() {
        var running = true
        while running {
            displayMenu()
            if let choice = readLine() {
                switch choice {
                case "1":
                    let square = Square()
                    square.displayArea()
                case "2":
                    let rectangle = Rectangle()
                    rectangle.displayArea()
                case "3":
                    let triangle = Triangle()
                    triangle.displayArea()
                case "4":
                    let circle = Circle()
                    circle.displayArea()
                case "5":
                    running = false
                    print("Saliendo de la aplicación. ¡Hasta pronto!")
                default:
                    print("Opción no válida. Por favor, elige un número del 1 al 5.")
                }
            } else {
                print("Error al leer la entrada. Por favor, intenta de nuevo.")
            }
        }
    }

    private func displayMenu() {
        print("\n--- Menú de Cálculo de Áreas ---")
        print("1. Área del cuadrado")
        print("2. Área del rectángulo")
        print("3. Área del triángulo")
        print("4. Área del círculo")
        print("5. Salir")
        print("Elige una opción:")
    }
}

// Iniciar la aplicación
let app = AreaCalculatorApp()
app.run()