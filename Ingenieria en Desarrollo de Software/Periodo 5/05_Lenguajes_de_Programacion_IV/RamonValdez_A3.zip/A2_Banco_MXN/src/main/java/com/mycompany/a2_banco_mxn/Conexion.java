/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a2_banco_mxn;


import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author ramon.valdez
 */
public class Conexion {
    public Connection getConnection(){
        Connection cnc = null;
        String url = "jdbc:mysql://localhost:3306/bco_mxn";
        String user = "root";
        String pass = "4Pp.Bc0mX_A3";
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            cnc = (Connection) DriverManager.getConnection(url, user, pass);        
        } catch(Exception e){
            System.out.println(e);
        }
        return cnc;
    } 
}
