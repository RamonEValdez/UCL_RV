/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a2_banco_mxn;

/**
 *
 * @author ramon.valdez
 */
public class Conexion {
    
}
