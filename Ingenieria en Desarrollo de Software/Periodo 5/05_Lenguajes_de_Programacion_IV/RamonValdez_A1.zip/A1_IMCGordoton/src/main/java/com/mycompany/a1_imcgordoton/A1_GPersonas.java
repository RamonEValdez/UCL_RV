/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a1_imcgordoton;

/**
 *
 * @author ramon.valdez
 */
public class A1_GPersonas {
    
    private double est;
    private double peso;

    public double getEst() { return est; }
    public void setEst(double est) { this.est = est; }

    public double getPeso() { return peso; }
    public void setPeso(double peso) { this.peso = peso; }

    public double obtrIMC() {
        return peso / Math.pow(est, 2);
    }
}
