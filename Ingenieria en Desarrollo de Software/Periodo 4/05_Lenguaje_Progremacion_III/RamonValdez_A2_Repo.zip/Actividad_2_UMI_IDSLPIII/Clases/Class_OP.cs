﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2_UMI_IDSLPIII.Clases
{
    public class Class_OP
    {
        public int Multiplicar (int num1, int num2, int num3, int num4, int num5, int num6)
        {
            int result;
            result = num1 * num2 * num3 * num4 * num5 * num6;
            return result;
        }
        public int Suma (int num1, int num2, int num3, int num4, int num5, int num6)
        {
            int result;
            result = num1 + num2 + num3 + num4 + num5 + num6;
            return result;
        }
        public int Resta(int num1, int num2, int num3, int num4, int num5, int num6)
        {
            int result;
            result = num1 - num2 - num3 - num4 - num5 - num6;
            return result;
        }

        public float Dividir(float num1, float num2, float num3, float num4, float num5, float num6)
        {
            float result;
            result = num1 / num2 / num3 / num4 / num5 / num6;
            return result;
        }
        public bool textVacios(TextBox[] txt_v)
        {
            foreach (TextBox textbox in txt_v)
            {
                if (textbox.Text == string.Empty)
                {
                    textbox.Focus();
                    return true;
                }
            }
            return false;
        }

    }
}
