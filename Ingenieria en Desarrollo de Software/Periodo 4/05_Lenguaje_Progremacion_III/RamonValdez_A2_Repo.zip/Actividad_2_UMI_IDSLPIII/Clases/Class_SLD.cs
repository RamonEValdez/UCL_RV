﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2_UMI_IDSLPIII.Clases
{
    public class Class_SLD
    {
        public string saludo (string nombre)
        {
            string sld; 
            sld = "Hola " + nombre + ", Que tengas un día Exelente.";
            return sld;
        }
         
    }
}