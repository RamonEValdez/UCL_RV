﻿namespace Actividad_2_UMI_IDSLPIII.Forms_A2
{
    partial class Form_DP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_DP));
            this.tabCtrl_DP = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtB_Nom = new System.Windows.Forms.TextBox();
            this.txtB_Ape = new System.Windows.Forms.TextBox();
            this.txtB_Cdad = new System.Windows.Forms.TextBox();
            this.txtB_Dir = new System.Windows.Forms.TextBox();
            this.dTP_FN = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cB_EC = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rBtt_Man = new System.Windows.Forms.RadioButton();
            this.rBtt_Wom = new System.Windows.Forms.RadioButton();
            this.btt_Vvr = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btt_Vvr2 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.tabCtrl_DP.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCtrl_DP
            // 
            this.tabCtrl_DP.AccessibleDescription = "Datos";
            this.tabCtrl_DP.AccessibleName = "Datos";
            this.tabCtrl_DP.Controls.Add(this.tabPage1);
            this.tabCtrl_DP.Controls.Add(this.tabPage2);
            this.tabCtrl_DP.Location = new System.Drawing.Point(12, 2);
            this.tabCtrl_DP.Name = "tabCtrl_DP";
            this.tabCtrl_DP.SelectedIndex = 0;
            this.tabCtrl_DP.Size = new System.Drawing.Size(776, 436);
            this.tabCtrl_DP.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.btt_Vvr);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 410);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Datos Alumno";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.btt_Vvr2);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 410);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Expediente Medico";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(18, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(17, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Apellido:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(17, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Direccion:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(18, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ciudad:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rBtt_Wom);
            this.groupBox1.Controls.Add(this.rBtt_Man);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.cB_EC);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dTP_FN);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtB_Dir);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtB_Cdad);
            this.groupBox1.Controls.Add(this.txtB_Ape);
            this.groupBox1.Controls.Add(this.txtB_Nom);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox1.Location = new System.Drawing.Point(6, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(682, 273);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos Personales Alumno";
            // 
            // txtB_Nom
            // 
            this.txtB_Nom.Location = new System.Drawing.Point(93, 30);
            this.txtB_Nom.Name = "txtB_Nom";
            this.txtB_Nom.Size = new System.Drawing.Size(278, 31);
            this.txtB_Nom.TabIndex = 1;
            // 
            // txtB_Ape
            // 
            this.txtB_Ape.Location = new System.Drawing.Point(93, 78);
            this.txtB_Ape.Name = "txtB_Ape";
            this.txtB_Ape.Size = new System.Drawing.Size(278, 31);
            this.txtB_Ape.TabIndex = 2;
            // 
            // txtB_Cdad
            // 
            this.txtB_Cdad.Location = new System.Drawing.Point(93, 214);
            this.txtB_Cdad.Name = "txtB_Cdad";
            this.txtB_Cdad.Size = new System.Drawing.Size(278, 31);
            this.txtB_Cdad.TabIndex = 3;
            // 
            // txtB_Dir
            // 
            this.txtB_Dir.Location = new System.Drawing.Point(93, 125);
            this.txtB_Dir.Multiline = true;
            this.txtB_Dir.Name = "txtB_Dir";
            this.txtB_Dir.Size = new System.Drawing.Size(278, 73);
            this.txtB_Dir.TabIndex = 4;
            // 
            // dTP_FN
            // 
            this.dTP_FN.Location = new System.Drawing.Point(442, 45);
            this.dTP_FN.Name = "dTP_FN";
            this.dTP_FN.Size = new System.Drawing.Size(200, 31);
            this.dTP_FN.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(475, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Fecha Nacimiento:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(493, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 19);
            this.label6.TabIndex = 7;
            this.label6.Text = "Estado Civil:";
            // 
            // cB_EC
            // 
            this.cB_EC.FormattingEnabled = true;
            this.cB_EC.Items.AddRange(new object[] {
            "Soltero.",
            "Soltera.",
            "Casado.",
            "Casada.",
            "Divorciado.",
            "Divorciado.",
            "Viudo.",
            "Viuda."});
            this.cB_EC.Location = new System.Drawing.Point(439, 188);
            this.cB_EC.Name = "cB_EC";
            this.cB_EC.Size = new System.Drawing.Size(202, 31);
            this.cB_EC.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(521, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 19);
            this.label7.TabIndex = 9;
            this.label7.Text = "Sexo:";
            // 
            // rBtt_Man
            // 
            this.rBtt_Man.AutoSize = true;
            this.rBtt_Man.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rBtt_Man.Location = new System.Drawing.Point(436, 114);
            this.rBtt_Man.Name = "rBtt_Man";
            this.rBtt_Man.Size = new System.Drawing.Size(88, 22);
            this.rBtt_Man.TabIndex = 10;
            this.rBtt_Man.TabStop = true;
            this.rBtt_Man.Text = "Maculino.";
            this.rBtt_Man.UseVisualStyleBackColor = true;
            // 
            // rBtt_Wom
            // 
            this.rBtt_Wom.AutoSize = true;
            this.rBtt_Wom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rBtt_Wom.Location = new System.Drawing.Point(549, 114);
            this.rBtt_Wom.Name = "rBtt_Wom";
            this.rBtt_Wom.Size = new System.Drawing.Size(93, 22);
            this.rBtt_Wom.TabIndex = 11;
            this.rBtt_Wom.TabStop = true;
            this.rBtt_Wom.Text = "Femenino.";
            this.rBtt_Wom.UseVisualStyleBackColor = true;
            // 
            // btt_Vvr
            // 
            this.btt_Vvr.BackColor = System.Drawing.Color.White;
            this.btt_Vvr.ForeColor = System.Drawing.Color.White;
            this.btt_Vvr.Image = ((System.Drawing.Image)(resources.GetObject("btt_Vvr.Image")));
            this.btt_Vvr.Location = new System.Drawing.Point(577, 334);
            this.btt_Vvr.Name = "btt_Vvr";
            this.btt_Vvr.Size = new System.Drawing.Size(111, 51);
            this.btt_Vvr.TabIndex = 5;
            this.btt_Vvr.UseVisualStyleBackColor = false;
            this.btt_Vvr.Click += new System.EventHandler(this.btt_Vvr_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox9);
            this.groupBox2.Controls.Add(this.checkBox10);
            this.groupBox2.Controls.Add(this.checkBox7);
            this.groupBox2.Controls.Add(this.checkBox8);
            this.groupBox2.Controls.Add(this.checkBox5);
            this.groupBox2.Controls.Add(this.checkBox6);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.checkBox4);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(19, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(632, 285);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Expediente Medico.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(252, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "1. ¿Padeces de alguna enfermedad?";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 106);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 19);
            this.label9.TabIndex = 1;
            this.label9.Text = "2. ¿Tienes alergias?";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(18, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(223, 19);
            this.label10.TabIndex = 2;
            this.label10.Text = "3. ¿Alguna vez te han operado?";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(395, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 19);
            this.label11.TabIndex = 3;
            this.label11.Text = "4. ¿Haces ejercicio?";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(395, 106);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(187, 19);
            this.label12.TabIndex = 4;
            this.label12.Text = "5. ¿Padeces de depresión?";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(447, 198);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(87, 19);
            this.label13.TabIndex = 15;
            this.label13.Text = "Efermedad:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Meningitis.",
            "Faringitis.",
            "Sinusitis.",
            "Infecciones del oído.",
            "Resfriados.",
            "Gripe.",
            "Mononucleosis.",
            "Otra."});
            this.comboBox1.Location = new System.Drawing.Point(392, 220);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(194, 31);
            this.comboBox1.TabIndex = 16;
            // 
            // btt_Vvr2
            // 
            this.btt_Vvr2.BackColor = System.Drawing.Color.White;
            this.btt_Vvr2.ForeColor = System.Drawing.SystemColors.Window;
            this.btt_Vvr2.Image = ((System.Drawing.Image)(resources.GetObject("btt_Vvr2.Image")));
            this.btt_Vvr2.Location = new System.Drawing.Point(595, 335);
            this.btt_Vvr2.Name = "btt_Vvr2";
            this.btt_Vvr2.Size = new System.Drawing.Size(138, 54);
            this.btt_Vvr2.TabIndex = 1;
            this.btt_Vvr2.UseVisualStyleBackColor = false;
            this.btt_Vvr2.Click += new System.EventHandler(this.btt_Vvr2_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(34, 63);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 27);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.Text = "Si.";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(150, 63);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(57, 27);
            this.checkBox2.TabIndex = 18;
            this.checkBox2.Text = "No.";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(150, 128);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(57, 27);
            this.checkBox3.TabIndex = 20;
            this.checkBox3.Text = "No.";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(34, 128);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(48, 27);
            this.checkBox4.TabIndex = 19;
            this.checkBox4.Text = "Si.";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(150, 198);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(57, 27);
            this.checkBox5.TabIndex = 22;
            this.checkBox5.Text = "No.";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(34, 198);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(48, 27);
            this.checkBox6.TabIndex = 21;
            this.checkBox6.Text = "Si.";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(531, 63);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(57, 27);
            this.checkBox7.TabIndex = 24;
            this.checkBox7.Text = "No.";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(415, 63);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(48, 27);
            this.checkBox8.TabIndex = 23;
            this.checkBox8.Text = "Si.";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(531, 128);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(57, 27);
            this.checkBox9.TabIndex = 26;
            this.checkBox9.Text = "No.";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(415, 128);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(48, 27);
            this.checkBox10.TabIndex = 25;
            this.checkBox10.Text = "Si.";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // Form_DP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabCtrl_DP);
            this.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_DP";
            this.Text = "Datos Personales.";
            this.tabCtrl_DP.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtrl_DP;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtB_Cdad;
        private System.Windows.Forms.TextBox txtB_Ape;
        private System.Windows.Forms.TextBox txtB_Nom;
        private System.Windows.Forms.TextBox txtB_Dir;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dTP_FN;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cB_EC;
        private System.Windows.Forms.RadioButton rBtt_Wom;
        private System.Windows.Forms.RadioButton rBtt_Man;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btt_Vvr;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btt_Vvr2;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}