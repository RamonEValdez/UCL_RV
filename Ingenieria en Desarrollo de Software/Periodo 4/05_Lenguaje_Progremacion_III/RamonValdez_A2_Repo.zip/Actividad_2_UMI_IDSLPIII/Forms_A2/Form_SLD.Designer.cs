﻿namespace Actividad_2_UMI_IDSLPIII.Forms_A2
{
    partial class Form_SLD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_SLD));
            this.lbl_Nom = new System.Windows.Forms.Label();
            this.txtB_Nom = new System.Windows.Forms.TextBox();
            this.btt_Saludo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btt_Salir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Nom
            // 
            this.lbl_Nom.AutoSize = true;
            this.lbl_Nom.BackColor = System.Drawing.SystemColors.WindowText;
            this.lbl_Nom.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nom.ForeColor = System.Drawing.SystemColors.Window;
            this.lbl_Nom.Location = new System.Drawing.Point(57, 101);
            this.lbl_Nom.Name = "lbl_Nom";
            this.lbl_Nom.Size = new System.Drawing.Size(80, 23);
            this.lbl_Nom.TabIndex = 0;
            this.lbl_Nom.Text = "Nombre:";
            // 
            // txtB_Nom
            // 
            this.txtB_Nom.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_Nom.Location = new System.Drawing.Point(61, 127);
            this.txtB_Nom.Name = "txtB_Nom";
            this.txtB_Nom.Size = new System.Drawing.Size(336, 31);
            this.txtB_Nom.TabIndex = 1;
            this.txtB_Nom.Text = "Escribe Tu Nombre";
            this.txtB_Nom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtB_Nom.TextChanged += new System.EventHandler(this.txtB_Nom_TextChanged);
            // 
            // btt_Saludo
            // 
            this.btt_Saludo.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btt_Saludo.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Saludo.Location = new System.Drawing.Point(61, 267);
            this.btt_Saludo.Name = "btt_Saludo";
            this.btt_Saludo.Size = new System.Drawing.Size(173, 67);
            this.btt_Saludo.TabIndex = 2;
            this.btt_Saludo.Text = "Saludo";
            this.btt_Saludo.UseVisualStyleBackColor = false;
            this.btt_Saludo.Click += new System.EventHandler(this.btt_Saludo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.WindowText;
            this.label1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkCyan;
            this.label1.Location = new System.Drawing.Point(23, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(795, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Esta es la ventana de saludo de la actividad  2:  Materia de  Lenguaje de Program" +
    "acion II de la Univercidad UMI.";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(490, 67);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(319, 267);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btt_Salir
            // 
            this.btt_Salir.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btt_Salir.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Salir.Location = new System.Drawing.Point(289, 267);
            this.btt_Salir.Name = "btt_Salir";
            this.btt_Salir.Size = new System.Drawing.Size(173, 67);
            this.btt_Salir.TabIndex = 5;
            this.btt_Salir.Text = "Cerrar";
            this.btt_Salir.UseVisualStyleBackColor = false;
            this.btt_Salir.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form_SLD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.WindowText;
            this.ClientSize = new System.Drawing.Size(828, 350);
            this.Controls.Add(this.btt_Salir);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btt_Saludo);
            this.Controls.Add(this.txtB_Nom);
            this.Controls.Add(this.lbl_Nom);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_SLD";
            this.Text = "Saludo.";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Nom;
        private System.Windows.Forms.TextBox txtB_Nom;
        private System.Windows.Forms.Button btt_Saludo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btt_Salir;
    }
}