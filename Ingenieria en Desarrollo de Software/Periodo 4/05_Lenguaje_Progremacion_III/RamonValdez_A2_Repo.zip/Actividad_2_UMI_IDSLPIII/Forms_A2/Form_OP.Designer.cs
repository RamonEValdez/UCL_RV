﻿namespace Actividad_2_UMI_IDSLPIII.Forms_A2
{
    partial class Form_OP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_OP));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtB_V4 = new System.Windows.Forms.TextBox();
            this.txtB_V1 = new System.Windows.Forms.TextBox();
            this.txtB_V5 = new System.Windows.Forms.TextBox();
            this.txtB_V6 = new System.Windows.Forms.TextBox();
            this.txtB_V2 = new System.Windows.Forms.TextBox();
            this.txtB_V3 = new System.Windows.Forms.TextBox();
            this.txtB_Reslt = new System.Windows.Forms.TextBox();
            this.btt_Suma = new System.Windows.Forms.Button();
            this.btt_mult = new System.Windows.Forms.Button();
            this.btt_resta = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btt_Vvr = new System.Windows.Forms.Button();
            this.btt_Lmp = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(52, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Valor #1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(52, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Valor #2:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(52, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Valor #3:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(265, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Valor #4:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(265, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 19);
            this.label5.TabIndex = 4;
            this.label5.Text = "Valor #5:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(265, 158);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 19);
            this.label6.TabIndex = 5;
            this.label6.Text = "Valor #6:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(72, 222);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 23);
            this.label7.TabIndex = 6;
            this.label7.Text = "Resultado:";
            // 
            // txtB_V4
            // 
            this.txtB_V4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_V4.Location = new System.Drawing.Point(331, 62);
            this.txtB_V4.Name = "txtB_V4";
            this.txtB_V4.Size = new System.Drawing.Size(117, 23);
            this.txtB_V4.TabIndex = 7;
            this.txtB_V4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB_V1
            // 
            this.txtB_V1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_V1.Location = new System.Drawing.Point(118, 63);
            this.txtB_V1.Name = "txtB_V1";
            this.txtB_V1.Size = new System.Drawing.Size(117, 23);
            this.txtB_V1.TabIndex = 8;
            this.txtB_V1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB_V5
            // 
            this.txtB_V5.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_V5.Location = new System.Drawing.Point(331, 111);
            this.txtB_V5.Name = "txtB_V5";
            this.txtB_V5.Size = new System.Drawing.Size(117, 23);
            this.txtB_V5.TabIndex = 9;
            this.txtB_V5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB_V6
            // 
            this.txtB_V6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_V6.Location = new System.Drawing.Point(331, 157);
            this.txtB_V6.Name = "txtB_V6";
            this.txtB_V6.Size = new System.Drawing.Size(117, 23);
            this.txtB_V6.TabIndex = 10;
            this.txtB_V6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB_V2
            // 
            this.txtB_V2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_V2.Location = new System.Drawing.Point(118, 111);
            this.txtB_V2.Name = "txtB_V2";
            this.txtB_V2.Size = new System.Drawing.Size(117, 23);
            this.txtB_V2.TabIndex = 11;
            this.txtB_V2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB_V3
            // 
            this.txtB_V3.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_V3.Location = new System.Drawing.Point(118, 158);
            this.txtB_V3.Name = "txtB_V3";
            this.txtB_V3.Size = new System.Drawing.Size(117, 23);
            this.txtB_V3.TabIndex = 12;
            this.txtB_V3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtB_Reslt
            // 
            this.txtB_Reslt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtB_Reslt.Location = new System.Drawing.Point(182, 222);
            this.txtB_Reslt.Name = "txtB_Reslt";
            this.txtB_Reslt.Size = new System.Drawing.Size(170, 31);
            this.txtB_Reslt.TabIndex = 13;
            this.txtB_Reslt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btt_Suma
            // 
            this.btt_Suma.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btt_Suma.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Suma.Location = new System.Drawing.Point(480, 62);
            this.btt_Suma.Name = "btt_Suma";
            this.btt_Suma.Size = new System.Drawing.Size(125, 48);
            this.btt_Suma.TabIndex = 14;
            this.btt_Suma.Text = "SUMA";
            this.btt_Suma.UseVisualStyleBackColor = false;
            this.btt_Suma.Click += new System.EventHandler(this.button1_Click);
            // 
            // btt_mult
            // 
            this.btt_mult.BackColor = System.Drawing.Color.Gold;
            this.btt_mult.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_mult.Location = new System.Drawing.Point(480, 133);
            this.btt_mult.Name = "btt_mult";
            this.btt_mult.Size = new System.Drawing.Size(125, 48);
            this.btt_mult.TabIndex = 15;
            this.btt_mult.Text = "MULTIPLICAR";
            this.btt_mult.UseVisualStyleBackColor = false;
            this.btt_mult.Click += new System.EventHandler(this.btt_mult_Click);
            // 
            // btt_resta
            // 
            this.btt_resta.BackColor = System.Drawing.Color.Red;
            this.btt_resta.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_resta.Location = new System.Drawing.Point(645, 63);
            this.btt_resta.Name = "btt_resta";
            this.btt_resta.Size = new System.Drawing.Size(125, 48);
            this.btt_resta.TabIndex = 16;
            this.btt_resta.Text = "RESTA";
            this.btt_resta.UseVisualStyleBackColor = false;
            this.btt_resta.Click += new System.EventHandler(this.btt_resta_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(645, 132);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(125, 48);
            this.button4.TabIndex = 17;
            this.button4.Text = "DIVIDIR";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btt_Vvr
            // 
            this.btt_Vvr.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btt_Vvr.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Vvr.Location = new System.Drawing.Point(645, 205);
            this.btt_Vvr.Name = "btt_Vvr";
            this.btt_Vvr.Size = new System.Drawing.Size(125, 48);
            this.btt_Vvr.TabIndex = 18;
            this.btt_Vvr.Text = "REGRESAR";
            this.btt_Vvr.UseVisualStyleBackColor = false;
            this.btt_Vvr.Click += new System.EventHandler(this.btt_Vvr_Click);
            // 
            // btt_Lmp
            // 
            this.btt_Lmp.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btt_Lmp.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Lmp.Location = new System.Drawing.Point(480, 205);
            this.btt_Lmp.Name = "btt_Lmp";
            this.btt_Lmp.Size = new System.Drawing.Size(125, 48);
            this.btt_Lmp.TabIndex = 19;
            this.btt_Lmp.Text = "LIMPIAR";
            this.btt_Lmp.UseVisualStyleBackColor = false;
            this.btt_Lmp.Click += new System.EventHandler(this.btt_Lmp_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(131, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(499, 23);
            this.label8.TabIndex = 20;
            this.label8.Text = "Operaciones Basicas Actividad 2: Lenguajes de Progrmacion III";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Window;
            this.label9.Location = new System.Drawing.Point(192, 284);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(343, 23);
            this.label9.TabIndex = 21;
            this.label9.Text = "Ingenieria de Desarrollo de Software UMI.";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Form_OP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowText;
            this.ClientSize = new System.Drawing.Size(793, 341);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btt_Lmp);
            this.Controls.Add(this.btt_Vvr);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btt_resta);
            this.Controls.Add(this.btt_mult);
            this.Controls.Add(this.btt_Suma);
            this.Controls.Add(this.txtB_Reslt);
            this.Controls.Add(this.txtB_V3);
            this.Controls.Add(this.txtB_V2);
            this.Controls.Add(this.txtB_V6);
            this.Controls.Add(this.txtB_V5);
            this.Controls.Add(this.txtB_V1);
            this.Controls.Add(this.txtB_V4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_OP";
            this.Text = "Operaciones Basicas UMI.";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtB_V4;
        private System.Windows.Forms.TextBox txtB_V1;
        private System.Windows.Forms.TextBox txtB_V5;
        private System.Windows.Forms.TextBox txtB_V6;
        private System.Windows.Forms.TextBox txtB_V2;
        private System.Windows.Forms.TextBox txtB_V3;
        private System.Windows.Forms.TextBox txtB_Reslt;
        private System.Windows.Forms.Button btt_Suma;
        private System.Windows.Forms.Button btt_mult;
        private System.Windows.Forms.Button btt_resta;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btt_Vvr;
        private System.Windows.Forms.Button btt_Lmp;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}