﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2_UMI_IDSLPIII.Forms_A2
{
    public partial class Form_SLD : Form
    {
        public Form_SLD()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btt_Saludo_Click(object sender, EventArgs e)
        {
            Clases.Class_SLD cls_SLD = new Clases.Class_SLD();
            string MiSaludo = cls_SLD.saludo(txtB_Nom.Text);
            MessageBox.Show(MiSaludo, "Campos Saludos");    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtB_Nom_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
