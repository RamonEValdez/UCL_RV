﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2_UMI_IDSLPIII.Forms_A2
{
    public partial class Form_OP : Form
    {
        public Form_OP()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clases.Class_OP cls_v = new Clases.Class_OP();
            if (cls_v.textVacios(new TextBox[] { txtB_V1, txtB_V2, txtB_V3, txtB_V4, txtB_V5, txtB_V6 }))
            {
                MessageBox.Show("Todos los campos deben ser completados.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                int result;
                Clases.Class_OP cls_suma = new Clases.Class_OP();
                result = cls_suma.Suma(int.Parse(txtB_V1.Text), int.Parse(txtB_V2.Text), int.Parse(txtB_V3.Text), int.Parse(txtB_V4.Text), int.Parse(txtB_V5.Text), int.Parse(txtB_V6.Text));
                txtB_Reslt.Text = result.ToString();
            }
        }
       
        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void btt_mult_Click(object sender, EventArgs e)
        {
            Clases.Class_OP cls_v = new Clases.Class_OP();
            if (cls_v.textVacios(new TextBox[] { txtB_V1, txtB_V2, txtB_V3, txtB_V4, txtB_V5, txtB_V6 }))
            {
                MessageBox.Show("Todos los campos deben ser completados.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                int result;
                Clases.Class_OP cls_mult = new Clases.Class_OP();
                result = cls_mult.Multiplicar(int.Parse(txtB_V1.Text), int.Parse(txtB_V2.Text), int.Parse(txtB_V3.Text), int.Parse(txtB_V4.Text), int.Parse(txtB_V5.Text), int.Parse(txtB_V6.Text));
                txtB_Reslt.Text = result.ToString();
            }
        }

        private void btt_resta_Click(object sender, EventArgs e)
        {
            Clases.Class_OP cls_v = new Clases.Class_OP();
            if (cls_v.textVacios(new TextBox[] { txtB_V1, txtB_V2, txtB_V3, txtB_V4, txtB_V5, txtB_V6 }))
            {
                MessageBox.Show("Todos los campos deben ser completados.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                int result;
                Clases.Class_OP cls_rest = new Clases.Class_OP();
                result = cls_rest.Resta(int.Parse(txtB_V1.Text), int.Parse(txtB_V2.Text), int.Parse(txtB_V3.Text), int.Parse(txtB_V4.Text), int.Parse(txtB_V5.Text), int.Parse(txtB_V6.Text));
                txtB_Reslt.Text = result.ToString();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Clases.Class_OP cls_v = new Clases.Class_OP();
            if (cls_v.textVacios(new TextBox[] { txtB_V1, txtB_V2, txtB_V3, txtB_V4, txtB_V5, txtB_V6 }))
            {
                MessageBox.Show("Todos los campos deben ser completados.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                float result;
                Clases.Class_OP cls_div = new Clases.Class_OP();
                result = cls_div.Dividir(float.Parse(txtB_V1.Text), float.Parse(txtB_V2.Text), float.Parse(txtB_V3.Text), float.Parse(txtB_V4.Text), float.Parse(txtB_V5.Text), float.Parse(txtB_V6.Text));
                txtB_Reslt.Text = result.ToString();
            }
        }

        private void btt_Lmp_Click(object sender, EventArgs e)
        {
            txtB_V1.Clear(); txtB_V2.Clear(); txtB_V3.Clear(); txtB_V4.Clear(); txtB_V5.Clear(); txtB_V6.Clear(); txtB_Reslt.Clear();
        }

        private void btt_Vvr_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
