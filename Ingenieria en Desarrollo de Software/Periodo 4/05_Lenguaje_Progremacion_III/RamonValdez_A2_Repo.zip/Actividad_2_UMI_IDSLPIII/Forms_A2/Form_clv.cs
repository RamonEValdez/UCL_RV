﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2_UMI_IDSLPIII.Forms_A2
{
    public partial class Form_clv : Form
    {
        public Form_clv()
        {
            InitializeComponent();
        }

        private void btt_entra_Click(object sender, EventArgs e)
        {
            if (txtB_Clv.Text == "")
            {
                MessageBox.Show("Debe ingerar la contraseña");
            }
            else if (txtB_Clv.Text == "Pa$$w0rd")
            { 
                Form_MP fm_MP = new Form_MP();
                fm_MP.Show();
                this.Hide();
            }
            else 
            {
                MessageBox.Show("La Contraseña es Incorrecta.");
            }
        }
    }
}
