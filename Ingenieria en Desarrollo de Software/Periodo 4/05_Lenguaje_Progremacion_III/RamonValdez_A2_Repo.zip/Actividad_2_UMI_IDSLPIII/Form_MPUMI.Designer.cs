﻿namespace Actividad_2_UMI_IDSLPIII
{
    partial class Form_MP
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_MP));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.TSMIt_MenuOp = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIt_DatoP = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIt_OpcionB = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIt_Saludo = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMIt_Salir = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIt_MenuOp,
            this.TSMIt_Saludo,
            this.TSMIt_Salir});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(746, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // TSMIt_MenuOp
            // 
            this.TSMIt_MenuOp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMIt_DatoP,
            this.TSMIt_OpcionB});
            this.TSMIt_MenuOp.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSMIt_MenuOp.Name = "TSMIt_MenuOp";
            this.TSMIt_MenuOp.Size = new System.Drawing.Size(107, 20);
            this.TSMIt_MenuOp.Text = "Menu Opciones.";
            this.TSMIt_MenuOp.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // TSMIt_DatoP
            // 
            this.TSMIt_DatoP.BackColor = System.Drawing.SystemColors.Control;
            this.TSMIt_DatoP.ForeColor = System.Drawing.SystemColors.Highlight;
            this.TSMIt_DatoP.Name = "TSMIt_DatoP";
            this.TSMIt_DatoP.Size = new System.Drawing.Size(185, 22);
            this.TSMIt_DatoP.Text = "Datos Personales.";
            this.TSMIt_DatoP.Click += new System.EventHandler(this.TSMIt_DatoP_Click);
            // 
            // TSMIt_OpcionB
            // 
            this.TSMIt_OpcionB.BackColor = System.Drawing.SystemColors.Control;
            this.TSMIt_OpcionB.ForeColor = System.Drawing.SystemColors.Highlight;
            this.TSMIt_OpcionB.Name = "TSMIt_OpcionB";
            this.TSMIt_OpcionB.Size = new System.Drawing.Size(185, 22);
            this.TSMIt_OpcionB.Text = "Operaciones Basicas.";
            this.TSMIt_OpcionB.Click += new System.EventHandler(this.TSMIt_OpcionB_Click);
            // 
            // TSMIt_Saludo
            // 
            this.TSMIt_Saludo.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSMIt_Saludo.Name = "TSMIt_Saludo";
            this.TSMIt_Saludo.Size = new System.Drawing.Size(58, 20);
            this.TSMIt_Saludo.Text = "Saludo.";
            this.TSMIt_Saludo.Click += new System.EventHandler(this.TSMIt_Saludo_Click);
            // 
            // TSMIt_Salir
            // 
            this.TSMIt_Salir.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TSMIt_Salir.Name = "TSMIt_Salir";
            this.TSMIt_Salir.Size = new System.Drawing.Size(44, 20);
            this.TSMIt_Salir.Text = "Salir.";
            this.TSMIt_Salir.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // Form_MP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(746, 550);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form_MP";
            this.Text = "Menu Principal UMI.";
            this.Load += new System.EventHandler(this.Form_MP_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem TSMIt_MenuOp;
        private System.Windows.Forms.ToolStripMenuItem TSMIt_DatoP;
        private System.Windows.Forms.ToolStripMenuItem TSMIt_OpcionB;
        private System.Windows.Forms.ToolStripMenuItem TSMIt_Salir;
        private System.Windows.Forms.ToolStripMenuItem TSMIt_Saludo;
    }
}

