﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2_UMI_IDSLPIII
{
    public partial class Form_MP : Form
    {
        public Form_MP()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void TSMIt_Saludo_Click(object sender, EventArgs e)
        {
            Forms_A2.Form_SLD nForm_SLD = new Forms_A2.Form_SLD();
            nForm_SLD.Show();
        }

        private void TSMIt_OpcionB_Click(object sender, EventArgs e)
        {
            Forms_A2.Form_OP nForm_OP = new Forms_A2.Form_OP();
            nForm_OP.Show();
        }

        private void TSMIt_DatoP_Click(object sender, EventArgs e)
        {
            Forms_A2.Form_DP nForm_DP = new Forms_A2.Form_DP();
            nForm_DP.Show();
        }

        private void Form_MP_Load(object sender, EventArgs e)
        {

        }
    }
}
