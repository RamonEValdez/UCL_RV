﻿namespace Actividad_3_CRUD.Screen
{
    partial class Form_comp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_comp));
            this.grpB_COM = new System.Windows.Forms.GroupBox();
            this.btt_vtas = new System.Windows.Forms.Button();
            this.btt_sld = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.grpB_COM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // grpB_COM
            // 
            this.grpB_COM.BackColor = System.Drawing.Color.Transparent;
            this.grpB_COM.Controls.Add(this.dataGridView1);
            this.grpB_COM.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpB_COM.ForeColor = System.Drawing.Color.Red;
            this.grpB_COM.Location = new System.Drawing.Point(12, 25);
            this.grpB_COM.Name = "grpB_COM";
            this.grpB_COM.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.grpB_COM.Size = new System.Drawing.Size(670, 349);
            this.grpB_COM.TabIndex = 0;
            this.grpB_COM.TabStop = false;
            this.grpB_COM.Text = "Reporte Zapateria UMI";
            // 
            // btt_vtas
            // 
            this.btt_vtas.BackColor = System.Drawing.Color.Black;
            this.btt_vtas.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_vtas.ForeColor = System.Drawing.Color.Snow;
            this.btt_vtas.Location = new System.Drawing.Point(39, 399);
            this.btt_vtas.Name = "btt_vtas";
            this.btt_vtas.Size = new System.Drawing.Size(182, 61);
            this.btt_vtas.TabIndex = 0;
            this.btt_vtas.Text = "Ventas Mes.";
            this.btt_vtas.UseVisualStyleBackColor = false;
            this.btt_vtas.Click += new System.EventHandler(this.btt_vtas_Click);
            // 
            // btt_sld
            // 
            this.btt_sld.BackColor = System.Drawing.Color.Black;
            this.btt_sld.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_sld.ForeColor = System.Drawing.Color.Snow;
            this.btt_sld.Location = new System.Drawing.Point(467, 399);
            this.btt_sld.Name = "btt_sld";
            this.btt_sld.Size = new System.Drawing.Size(182, 61);
            this.btt_sld.TabIndex = 1;
            this.btt_sld.Text = "Salir.";
            this.btt_sld.UseVisualStyleBackColor = false;
            this.btt_sld.Click += new System.EventHandler(this.btt_sld_Click);
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(6, 102);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(647, 177);
            this.dataGridView1.TabIndex = 2;
            // 
            // Form_comp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(689, 498);
            this.Controls.Add(this.grpB_COM);
            this.Controls.Add(this.btt_vtas);
            this.Controls.Add(this.btt_sld);
            this.ForeColor = System.Drawing.Color.Red;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_comp";
            this.Text = "Compras Zapateria UMI";
            this.grpB_COM.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpB_COM;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btt_sld;
        private System.Windows.Forms.Button btt_vtas;
    }
}