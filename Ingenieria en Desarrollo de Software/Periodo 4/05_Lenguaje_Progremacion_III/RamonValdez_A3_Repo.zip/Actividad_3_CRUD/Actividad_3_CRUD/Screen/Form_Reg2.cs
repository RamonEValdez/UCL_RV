﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Screen
{
    public partial class Form_Reg2 : Form
    {
        public Form_Reg2()
        {
            InitializeComponent();
        }

        private void Form_Reg2_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btt_sld_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_vw_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from proveedor", cn);
                sda.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                sda.Fill(dt);
                dGV_pvr.DataSource = dt;
            }
        }

        private void btt_add_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                if (string.IsNullOrWhiteSpace(txtB_nom.Text) ||
                    string.IsNullOrWhiteSpace(txtB_ape.Text) ||
                    string.IsNullOrWhiteSpace(txtB_dir.Text) ||
                    string.IsNullOrWhiteSpace(txtB_pho.Text) ||
                    string.IsNullOrWhiteSpace(txtB_eml.Text))
                {
                    MessageBox.Show("Todos los campos son obligatorios para el alta del proveedor.", "Operación incorrecta");
                }
                else
                {

                    using (SqlCommand cmd = new SqlCommand("INSERT INTO proveedor (nombre, apellido, telefono, email, direccion) VALUES (@nombre, @apellido, @telefono, @email, @Dir)", cn))

                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("@nombre", txtB_nom.Text);
                        cmd.Parameters.AddWithValue("@apellido", txtB_ape.Text);
                        cmd.Parameters.AddWithValue("@Dir", txtB_dir.Text);
                        cmd.Parameters.AddWithValue("@telefono", txtB_pho.Text);
                        cmd.Parameters.AddWithValue("@email", txtB_eml.Text);
                        cmd.ExecuteNonQuery();

                        txtB_nom.Text = "";
                        txtB_ape.Text = "";
                        txtB_dir.Text = "";
                        txtB_pho.Text = "";
                        txtB_eml.Text = "";
                        MessageBox.Show("Registro exitoso de proveedor nuevo.", "Registro Proveedor.");
                    }
                }
            }
        }

        private void btt_mod_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                string id = txtB_ID.Text;
                bool idExists = false;

                using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM proveedor WHERE id_proveedor = @id", cn))
                {
                    checkCmd.Parameters.AddWithValue("@id", id);
                    int count = (int)checkCmd.ExecuteScalar();
                    idExists = count > 0;
                }

                // Verificar si el ID existe y al menos un campo adicional no está vacío
                if (!idExists ||
                    (string.IsNullOrEmpty(txtB_nom.Text) &&
                     string.IsNullOrEmpty(txtB_ape.Text) &&
                     string.IsNullOrEmpty(txtB_dir.Text) &&
                     string.IsNullOrEmpty(txtB_pho.Text) &&
                     string.IsNullOrEmpty(txtB_eml.Text)))
                {
                    MessageBox.Show("El ID ingresado no existe o no se proporcionó información adicional para actualizar el registro.", "Error de Validación");
                }
                else
                {
                    // ID existe y al menos un campo adicional no está vacío, proceder con la actualización
                    StringBuilder queryBuilder = new StringBuilder("UPDATE proveedor SET ");

                    if (!string.IsNullOrEmpty(txtB_nom.Text))
                    {
                        queryBuilder.Append("nombre = @nombre, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_ape.Text))
                    {
                        queryBuilder.Append("apellido = @apellido, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_dir.Text))
                    {
                        queryBuilder.Append("direccion = @dir, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_pho.Text))
                    {
                        queryBuilder.Append("telefono = @telefono, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_eml.Text))
                    {
                        queryBuilder.Append("email = @email, ");
                    }

                    queryBuilder.Length -= 2;
                    queryBuilder.Append(" WHERE id_proveeor = @id");

                    using (SqlCommand cmd = new SqlCommand(queryBuilder.ToString(), cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@id", id);
                        if (!string.IsNullOrEmpty(txtB_nom.Text))
                        {
                            cmd.Parameters.AddWithValue("@nombre", txtB_nom.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_ape.Text))
                        {
                            cmd.Parameters.AddWithValue("@apellido", txtB_ape.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_dir.Text))
                        {
                            cmd.Parameters.AddWithValue("@dir", txtB_dir.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_pho.Text))
                        {
                            cmd.Parameters.AddWithValue("@telefono", txtB_pho.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_eml.Text))
                        {
                            cmd.Parameters.AddWithValue("@email", txtB_eml.Text);
                        }
                        cmd.ExecuteNonQuery();
                    }

                    // Vaciar text de update
                    txtB_ID.Text = "";
                    txtB_nom.Text = "";
                    txtB_ape.Text = "";
                    txtB_dir.Text = "";
                    txtB_pho.Text = "";
                    txtB_eml.Text = "";

                    MessageBox.Show("El registro fue modificado exitosamente.", "Registro Cliente Modificado");
                }

            }
        }

        private void btt_Elm_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                using (SqlCommand cmd = new SqlCommand("DELETE FROM proveedor WHERE id_proveedor = @id", cn))
                {
                    cmd.Parameters.AddWithValue("@id", txtB_ID.Text);
                    cmd.CommandType = CommandType.Text;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show($"Se eliminó el registro del Proveedor con el ID: {txtB_ID.Text}", "Éxito");
                    }
                    else
                    {
                        MessageBox.Show("No se encontró ningún proveedor para eliminar, Usar el capo ID correctamente.", "Aviso sin exito al eliminar");
                    }
                }
            }
        }

        private void btt_sld2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_vw2_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from producto", cn);
                sda.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                sda.Fill(dt);
                dGV_prod.DataSource = dt;
            }
        }

        private void btt_add2_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                if (string.IsNullOrWhiteSpace(txtB_pod.Text) ||
                    string.IsNullOrWhiteSpace(txtB_mar.Text) ||
                    string.IsNullOrWhiteSpace(txtB_ctg.Text) ||
                    string.IsNullOrWhiteSpace(txtB_zse.Text) ||
                    string.IsNullOrWhiteSpace(txtB_cst.Text) ||
                    string.IsNullOrWhiteSpace(txtB_sto.Text) ||
                    string.IsNullOrWhiteSpace(txtB_tpo.Text))
                {
                    MessageBox.Show("Todos los campos son obligatorios para el alta del producto.", "Operación incorrecta");
                }
                else
                {

                    using (SqlCommand cmd = new SqlCommand("INSERT INTO producto (nom_prod, Marc_prod, precio_prod, stock_prod, ctg, zise, tipo) VALUES (@prod, @marc, @precio, @stock, @ctg, @zse, @tpo)", cn))

                    {
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.AddWithValue("@prod", txtB_pod.Text);
                        cmd.Parameters.AddWithValue("@marc", txtB_mar.Text);
                        cmd.Parameters.AddWithValue("@precio", txtB_cst.Text);
                        cmd.Parameters.AddWithValue("@stock", txtB_sto.Text);
                        cmd.Parameters.AddWithValue("@ctg", txtB_ctg.Text);
                        cmd.Parameters.AddWithValue("@zse", txtB_zse.Text);
                        cmd.Parameters.AddWithValue("@tpo", txtB_tpo.Text);
                        cmd.ExecuteNonQuery();

                        txtB_pod.Text = "";
                        txtB_mar.Text = "";
                        txtB_cst.Text = "";
                        txtB_sto.Text = "";
                        txtB_ctg.Text = "";
                        txtB_zse.Text = "";
                        txtB_tpo.Text = "";

                        MessageBox.Show("Registro exitoso de producto nuevo.", "Registro Proveedor.");
                    }
                }
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btt_mod2_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                string id = txtB_id2.Text;
                bool idExists = false;

                using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM producto WHERE id_producto = @id", cn))
                {
                    checkCmd.Parameters.AddWithValue("@id", id);
                    int count = (int)checkCmd.ExecuteScalar();
                    idExists = count > 0;
                }

                // Verificar si el ID existe y al menos un campo adicional no está vacío
                if (!idExists ||
                    (string.IsNullOrEmpty(txtB_pod.Text) &&
                     string.IsNullOrEmpty(txtB_mar.Text) &&
                     string.IsNullOrEmpty(txtB_cst.Text) &&
                     string.IsNullOrEmpty(txtB_sto.Text) &&
                     string.IsNullOrEmpty(txtB_ctg.Text) &&
                     string.IsNullOrEmpty(txtB_zse.Text) &&
                     string.IsNullOrEmpty(txtB_tpo.Text)))
                {
                    MessageBox.Show("El ID ingresado no existe o no se proporcionó información adicional para actualizar el registro.", "Error de Validación");
                }
                else
                {
                    // ID existe y al menos un campo adicional no está vacío, proceder con la actualización
                    StringBuilder queryBuilder = new StringBuilder("UPDATE producto SET ");

                    if (!string.IsNullOrEmpty(txtB_pod.Text))
                    {
                        queryBuilder.Append("nom_prod = @prod, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_mar.Text))
                    {
                        queryBuilder.Append("Marc_prod = @marc, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_cst.Text))
                    {
                        queryBuilder.Append("precio_prod = @precio, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_sto.Text))
                    {
                        queryBuilder.Append("stock_prod = @stock, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_ctg.Text))
                    {
                        queryBuilder.Append("ctg = @ctg, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_zse.Text))
                    {
                        queryBuilder.Append("zise = @zse, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_tpo.Text))
                    {
                        queryBuilder.Append("tipo = @tpo, ");
                    }

                    queryBuilder.Length -= 2;
                    queryBuilder.Append(" WHERE id_producto = @id");

                    using (SqlCommand cmd = new SqlCommand(queryBuilder.ToString(), cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@id", id);
                        if (!string.IsNullOrEmpty(txtB_pod.Text))
                        {
                            cmd.Parameters.AddWithValue("@prod", txtB_pod.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_mar.Text))
                        {
                            cmd.Parameters.AddWithValue("@marc", txtB_mar.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_cst.Text))
                        {
                            cmd.Parameters.AddWithValue("@precio", txtB_cst.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_sto.Text))
                        {
                            cmd.Parameters.AddWithValue("@stock", txtB_sto.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_ctg.Text))
                        {
                            cmd.Parameters.AddWithValue("@ctg", txtB_ctg.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_zse.Text))
                        {
                            cmd.Parameters.AddWithValue("@zse", txtB_zse.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_tpo.Text))
                        {
                            cmd.Parameters.AddWithValue("@tpo", txtB_tpo.Text);
                        }
                        cmd.ExecuteNonQuery();
                    }

                    // Vaciar text de update
                    txtB_id2.Text = "";
                    txtB_pod.Text = "";
                    txtB_mar.Text = "";
                    txtB_cst.Text = "";
                    txtB_sto.Text = "";
                    txtB_ctg.Text = "";
                    txtB_zse.Text = "";
                    txtB_tpo.Text = "";

                    MessageBox.Show("El registro fue modificado exitosamente.", "Registro Cliente Modificado");
                }

            }

        }

        private void btt_elm2_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                using (SqlCommand cmd = new SqlCommand("DELETE FROM producto WHERE id_producto = @id", cn))
                {
                    cmd.Parameters.AddWithValue("@id", txtB_id2.Text);
                    cmd.CommandType = CommandType.Text;

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show($"Se eliminó el registro del producto con el ID: {txtB_ID.Text}", "Éxito");
                    }
                    else
                    {
                        MessageBox.Show("No se encontró ningún producto para eliminar, Usar el capo ID correctamente.", "Aviso sin exito al eliminar");
                    }
                }
            }

        }
    }
     
}
    
