﻿namespace Actividad_3_CRUD.Screen
{
    partial class Form_reg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_reg));
            this.gB_dp = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtB_ID = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.txtB_email = new System.Windows.Forms.TextBox();
            this.txtB_pho = new System.Windows.Forms.TextBox();
            this.txtB_fenac = new System.Windows.Forms.TextBox();
            this.txtB_ape = new System.Windows.Forms.TextBox();
            this.txtB_Nom = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btt_add = new System.Windows.Forms.Button();
            this.btt_edt = new System.Windows.Forms.Button();
            this.dGV_db = new System.Windows.Forms.DataGridView();
            this.btt_vw = new System.Windows.Forms.Button();
            this.btt_elmn = new System.Windows.Forms.Button();
            this.btt_sld = new System.Windows.Forms.Button();
            this.gB_dp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_db)).BeginInit();
            this.SuspendLayout();
            // 
            // gB_dp
            // 
            this.gB_dp.BackColor = System.Drawing.Color.Transparent;
            this.gB_dp.Controls.Add(this.label1);
            this.gB_dp.Controls.Add(this.txtB_ID);
            this.gB_dp.Controls.Add(this.lbl_ID);
            this.gB_dp.Controls.Add(this.txtB_email);
            this.gB_dp.Controls.Add(this.txtB_pho);
            this.gB_dp.Controls.Add(this.txtB_fenac);
            this.gB_dp.Controls.Add(this.txtB_ape);
            this.gB_dp.Controls.Add(this.txtB_Nom);
            this.gB_dp.Controls.Add(this.label6);
            this.gB_dp.Controls.Add(this.label5);
            this.gB_dp.Controls.Add(this.label4);
            this.gB_dp.Controls.Add(this.label3);
            this.gB_dp.Controls.Add(this.label2);
            this.gB_dp.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gB_dp.ForeColor = System.Drawing.Color.Black;
            this.gB_dp.Location = new System.Drawing.Point(12, 23);
            this.gB_dp.Name = "gB_dp";
            this.gB_dp.Size = new System.Drawing.Size(612, 411);
            this.gB_dp.TabIndex = 0;
            this.gB_dp.TabStop = false;
            this.gB_dp.Text = "Registro Cliente";
            this.gB_dp.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(197, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 52);
            this.label1.TabIndex = 14;
            this.label1.Text = "Usar este campo en la\r\n baja de un registro.";
            this.label1.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // txtB_ID
            // 
            this.txtB_ID.Location = new System.Drawing.Point(87, 36);
            this.txtB_ID.Name = "txtB_ID";
            this.txtB_ID.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtB_ID.Size = new System.Drawing.Size(106, 40);
            this.txtB_ID.TabIndex = 13;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_ID.Location = new System.Drawing.Point(35, 39);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(46, 33);
            this.lbl_ID.TabIndex = 12;
            this.lbl_ID.Text = "ID:";
            this.lbl_ID.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txtB_email
            // 
            this.txtB_email.Location = new System.Drawing.Point(247, 346);
            this.txtB_email.Name = "txtB_email";
            this.txtB_email.Size = new System.Drawing.Size(347, 40);
            this.txtB_email.TabIndex = 11;
            // 
            // txtB_pho
            // 
            this.txtB_pho.Location = new System.Drawing.Point(247, 292);
            this.txtB_pho.Name = "txtB_pho";
            this.txtB_pho.Size = new System.Drawing.Size(347, 40);
            this.txtB_pho.TabIndex = 10;
            // 
            // txtB_fenac
            // 
            this.txtB_fenac.Location = new System.Drawing.Point(247, 231);
            this.txtB_fenac.Name = "txtB_fenac";
            this.txtB_fenac.Size = new System.Drawing.Size(347, 40);
            this.txtB_fenac.TabIndex = 9;
            // 
            // txtB_ape
            // 
            this.txtB_ape.Location = new System.Drawing.Point(247, 160);
            this.txtB_ape.Name = "txtB_ape";
            this.txtB_ape.Size = new System.Drawing.Size(347, 40);
            this.txtB_ape.TabIndex = 8;
            // 
            // txtB_Nom
            // 
            this.txtB_Nom.Location = new System.Drawing.Point(247, 101);
            this.txtB_Nom.Name = "txtB_Nom";
            this.txtB_Nom.Size = new System.Drawing.Size(347, 40);
            this.txtB_Nom.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(35, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 33);
            this.label6.TabIndex = 5;
            this.label6.Text = "E-Mail:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(29, 292);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 33);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telefono:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(29, 207);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 66);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fecha de \r\nNacimiento:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(28, 167);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 33);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido(s):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(29, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre(s):";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btt_add
            // 
            this.btt_add.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btt_add.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_add.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_add.Location = new System.Drawing.Point(683, 76);
            this.btt_add.Name = "btt_add";
            this.btt_add.Size = new System.Drawing.Size(197, 60);
            this.btt_add.TabIndex = 1;
            this.btt_add.Text = "Alta.";
            this.btt_add.UseVisualStyleBackColor = false;
            this.btt_add.Click += new System.EventHandler(this.btt_add_Click);
            // 
            // btt_edt
            // 
            this.btt_edt.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btt_edt.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_edt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_edt.Location = new System.Drawing.Point(683, 159);
            this.btt_edt.Name = "btt_edt";
            this.btt_edt.Size = new System.Drawing.Size(197, 60);
            this.btt_edt.TabIndex = 2;
            this.btt_edt.Text = "Modificar.";
            this.btt_edt.UseVisualStyleBackColor = false;
            this.btt_edt.Click += new System.EventHandler(this.btt_edt_Click);
            // 
            // dGV_db
            // 
            this.dGV_db.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_db.Location = new System.Drawing.Point(12, 440);
            this.dGV_db.Name = "dGV_db";
            this.dGV_db.Size = new System.Drawing.Size(697, 172);
            this.dGV_db.TabIndex = 3;
            // 
            // btt_vw
            // 
            this.btt_vw.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btt_vw.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_vw.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_vw.Location = new System.Drawing.Point(683, 249);
            this.btt_vw.Name = "btt_vw";
            this.btt_vw.Size = new System.Drawing.Size(197, 60);
            this.btt_vw.TabIndex = 4;
            this.btt_vw.Text = "Mostrar.";
            this.btt_vw.UseVisualStyleBackColor = false;
            this.btt_vw.Click += new System.EventHandler(this.btt_vw_Click);
            // 
            // btt_elmn
            // 
            this.btt_elmn.BackColor = System.Drawing.Color.Red;
            this.btt_elmn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_elmn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_elmn.Location = new System.Drawing.Point(791, 326);
            this.btt_elmn.Name = "btt_elmn";
            this.btt_elmn.Size = new System.Drawing.Size(120, 64);
            this.btt_elmn.TabIndex = 5;
            this.btt_elmn.Text = "Eliminar.";
            this.btt_elmn.UseVisualStyleBackColor = false;
            this.btt_elmn.Click += new System.EventHandler(this.btt_elmn_Click);
            // 
            // btt_sld
            // 
            this.btt_sld.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btt_sld.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_sld.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_sld.Location = new System.Drawing.Point(640, 326);
            this.btt_sld.Name = "btt_sld";
            this.btt_sld.Size = new System.Drawing.Size(120, 64);
            this.btt_sld.TabIndex = 6;
            this.btt_sld.Text = "Salir.";
            this.btt_sld.UseVisualStyleBackColor = false;
            this.btt_sld.Click += new System.EventHandler(this.btt_sld_Click);
            // 
            // Form_reg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(923, 817);
            this.Controls.Add(this.btt_sld);
            this.Controls.Add(this.btt_elmn);
            this.Controls.Add(this.btt_vw);
            this.Controls.Add(this.dGV_db);
            this.Controls.Add(this.btt_edt);
            this.Controls.Add(this.btt_add);
            this.Controls.Add(this.gB_dp);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_reg";
            this.Text = "Registro Cliente  Zapateria UMI";
            this.gB_dp.ResumeLayout(false);
            this.gB_dp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_db)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gB_dp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtB_fenac;
        private System.Windows.Forms.TextBox txtB_ape;
        private System.Windows.Forms.TextBox txtB_Nom;
        private System.Windows.Forms.TextBox txtB_email;
        private System.Windows.Forms.TextBox txtB_pho;
        private System.Windows.Forms.Button btt_add;
        private System.Windows.Forms.Button btt_edt;
        private System.Windows.Forms.DataGridView dGV_db;
        private System.Windows.Forms.Button btt_vw;
        private System.Windows.Forms.Button btt_elmn;
        private System.Windows.Forms.Button btt_sld;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.TextBox txtB_ID;
        private System.Windows.Forms.Label label1;
    }
}