﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Screen
{
    public partial class Form_prod : Form
    {
        public Form_prod()
        {
            InitializeComponent();
        }

        private void Form_prod_Load(object sender, EventArgs e)
        {

        }

        private void btt_sld_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_car_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Los productos se han agregado al carrito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // Borrar CheckBox y ComboBox existentes
            if (cmbB_Prod.SelectedIndex != -1)
            {
                cmbB_Prod.Items.RemoveAt(cmbB_Prod.SelectedIndex);
            }
            if (cmbB_zse.SelectedIndex != -1)
            {
                cmbB_zse.Items.RemoveAt(cmbB_zse.SelectedIndex);
            }
            if (cmbB_clr.SelectedIndex != -1)
            {
                cmbB_clr.Items.RemoveAt(cmbB_clr.SelectedIndex);
            }

            picB_prod.Image = null;
            rdoB_D.Checked = false;
            rdoB_C.Checked = false;
            cmbB_Prod.Items.Clear();
            cmbB_zse.Items.Clear();
            cmbB_clr.Items.Clear();
        }

        private void rdoB_D_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoB_D.Checked)
               { 
                 string consulta = "SELECT DISTINCT nom_prod, CAST(zise AS INT) AS zise FROM producto WHERE ctg= 'Dama' ORDER BY nom_prod ASC, zise ASC";

                 using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
                 {
                    cmbB_Prod.Items.Clear();
                    cmbB_zse.Items.Clear();
                    cmbB_clr.Items.Clear();

                    HashSet<int> tamañosUnicos = new HashSet<int>(); // HashSet para almacenar tamaños únicos

                    SqlCommand command = new SqlCommand(consulta, cn);

                    try
                    {
                        cn.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            cmbB_Prod.Items.Add(reader["nom_prod"].ToString());

                            int tamaño = Convert.ToInt32(reader["zise"]);
                            if (!tamañosUnicos.Contains(tamaño)) // Verificar si el tamaño ya existe en HashSet
                            {
                                cmbB_zse.Items.Add(tamaño.ToString());
                                tamañosUnicos.Add(tamaño); // Agregar el tamaño al HashSet
                            }
                        }
                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al cargar los productos: " + ex.Message);
                    }
                 }
                cmbB_clr.Items.Add("Blanco");
                cmbB_clr.Items.Add("Negro");
                cmbB_clr.Items.Add("Rosa");
                cmbB_clr.Items.Add("Azul");
                cmbB_clr.Items.Add("Gris");
                cmbB_clr.Items.Add("Cafes");
                cmbB_clr.Items.Add("Plateado");
                cmbB_clr.Items.Add("Dorado");
            }
        }

        private void rdoB_C_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoB_C.Checked)
            {
                string consulta = "SELECT DISTINCT nom_prod, CAST(zise AS INT) AS zise FROM producto WHERE ctg= 'Caballero' ORDER BY nom_prod ASC, zise ASC";

                using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
                {
                    cmbB_Prod.Items.Clear();
                    cmbB_zse.Items.Clear();
                    cmbB_clr.Items.Clear();

                    HashSet<int> tamañosUnicos = new HashSet<int>(); // HashSet para almacenar tamaños únicos

                    SqlCommand command = new SqlCommand(consulta, cn);

                    try
                    {
                        cn.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            cmbB_Prod.Items.Add(reader["nom_prod"].ToString());

                            int tamaño = Convert.ToInt32(reader["zise"]);
                            if (!tamañosUnicos.Contains(tamaño)) // Verificar si el tamaño ya existe en HashSet
                            {
                                cmbB_zse.Items.Add(tamaño.ToString());
                                tamañosUnicos.Add(tamaño); // Agregar el tamaño al HashSet
                            }
                        }
                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al cargar los productos: " + ex.Message);
                    }
                }
                // Agregar colores al ComboBox de colores
                cmbB_clr.Items.Add("Blanco");
                cmbB_clr.Items.Add("Negro");
                cmbB_clr.Items.Add("Azul");
                cmbB_clr.Items.Add("Gris");
                cmbB_clr.Items.Add("Cafes");
            }

        }

        private void cmbB_Prod_SelectedIndexChanged(object sender, EventArgs e)
        {
            string productoSeleccionado = cmbB_Prod.SelectedItem.ToString();
            string consultaImagen = "SELECT img FROM producto WHERE nom_prod = @producto";

            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            using (SqlCommand command = new SqlCommand(consultaImagen, cn))
            {
                command.Parameters.AddWithValue("@producto", productoSeleccionado);

                try
                {
                    cn.Open();
                    byte[] imagenBytes = (byte[])command.ExecuteScalar(); // Obtener los bytes de la imagen directamente

                    // Crear un MemoryStream a partir de los bytes de la imagen
                    using (MemoryStream ms = new MemoryStream(imagenBytes))
                    {
                        // Cargar la imagen en el control PictureBox desde el MemoryStream
                        picB_prod.Image = Image.FromStream(ms);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar la imagen del producto: " + ex.Message);
                }
            }
        
        }
    }
}
