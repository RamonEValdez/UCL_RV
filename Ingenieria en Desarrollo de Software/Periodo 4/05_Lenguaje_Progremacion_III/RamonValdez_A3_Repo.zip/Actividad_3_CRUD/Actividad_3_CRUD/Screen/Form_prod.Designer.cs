﻿namespace Actividad_3_CRUD.Screen
{
    partial class Form_prod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_prod));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbB_zse = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbB_Prod = new System.Windows.Forms.ComboBox();
            this.btt_car = new System.Windows.Forms.Button();
            this.btt_sld = new System.Windows.Forms.Button();
            this.rdoB_D = new System.Windows.Forms.RadioButton();
            this.rdoB_C = new System.Windows.Forms.RadioButton();
            this.cmbB_clr = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.picB_prod = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picB_prod)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.picB_prod);
            this.groupBox1.Controls.Add(this.cmbB_clr);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.rdoB_C);
            this.groupBox1.Controls.Add(this.rdoB_D);
            this.groupBox1.Controls.Add(this.cmbB_zse);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cmbB_Prod);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Location = new System.Drawing.Point(12, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(532, 355);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Catalogo Zapateria";
            // 
            // cmbB_zse
            // 
            this.cmbB_zse.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.cmbB_zse.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbB_zse.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbB_zse.FormattingEnabled = true;
            this.cmbB_zse.Location = new System.Drawing.Point(296, 241);
            this.cmbB_zse.Name = "cmbB_zse";
            this.cmbB_zse.Size = new System.Drawing.Size(176, 31);
            this.cmbB_zse.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(300, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Talla:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(291, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Producto:";
            // 
            // cmbB_Prod
            // 
            this.cmbB_Prod.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.cmbB_Prod.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbB_Prod.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbB_Prod.FormattingEnabled = true;
            this.cmbB_Prod.Location = new System.Drawing.Point(296, 71);
            this.cmbB_Prod.Name = "cmbB_Prod";
            this.cmbB_Prod.Size = new System.Drawing.Size(176, 31);
            this.cmbB_Prod.TabIndex = 3;
            this.cmbB_Prod.SelectedIndexChanged += new System.EventHandler(this.cmbB_Prod_SelectedIndexChanged);
            // 
            // btt_car
            // 
            this.btt_car.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_car.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_car.Location = new System.Drawing.Point(87, 405);
            this.btt_car.Name = "btt_car";
            this.btt_car.Size = new System.Drawing.Size(177, 56);
            this.btt_car.TabIndex = 3;
            this.btt_car.Text = "Carrito.";
            this.btt_car.UseVisualStyleBackColor = false;
            this.btt_car.Click += new System.EventHandler(this.btt_car_Click);
            // 
            // btt_sld
            // 
            this.btt_sld.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_sld.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_sld.Location = new System.Drawing.Point(367, 405);
            this.btt_sld.Name = "btt_sld";
            this.btt_sld.Size = new System.Drawing.Size(177, 56);
            this.btt_sld.TabIndex = 4;
            this.btt_sld.Text = "Salir.";
            this.btt_sld.UseVisualStyleBackColor = false;
            this.btt_sld.Click += new System.EventHandler(this.btt_sld_Click);
            // 
            // rdoB_D
            // 
            this.rdoB_D.AutoSize = true;
            this.rdoB_D.Location = new System.Drawing.Point(21, 56);
            this.rdoB_D.Name = "rdoB_D";
            this.rdoB_D.Size = new System.Drawing.Size(111, 40);
            this.rdoB_D.TabIndex = 7;
            this.rdoB_D.TabStop = true;
            this.rdoB_D.Text = "Dama.";
            this.rdoB_D.UseVisualStyleBackColor = true;
            this.rdoB_D.CheckedChanged += new System.EventHandler(this.rdoB_D_CheckedChanged);
            // 
            // rdoB_C
            // 
            this.rdoB_C.AutoSize = true;
            this.rdoB_C.Location = new System.Drawing.Point(21, 102);
            this.rdoB_C.Name = "rdoB_C";
            this.rdoB_C.Size = new System.Drawing.Size(155, 40);
            this.rdoB_C.TabIndex = 8;
            this.rdoB_C.TabStop = true;
            this.rdoB_C.Text = "Caballero.";
            this.rdoB_C.UseVisualStyleBackColor = true;
            this.rdoB_C.CheckedChanged += new System.EventHandler(this.rdoB_C_CheckedChanged);
            // 
            // cmbB_clr
            // 
            this.cmbB_clr.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.cmbB_clr.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbB_clr.ForeColor = System.Drawing.SystemColors.Window;
            this.cmbB_clr.FormattingEnabled = true;
            this.cmbB_clr.Location = new System.Drawing.Point(296, 154);
            this.cmbB_clr.Name = "cmbB_clr";
            this.cmbB_clr.Size = new System.Drawing.Size(176, 31);
            this.cmbB_clr.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(300, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 29);
            this.label3.TabIndex = 9;
            this.label3.Text = "Color:";
            // 
            // picB_prod
            // 
            this.picB_prod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picB_prod.Location = new System.Drawing.Point(6, 148);
            this.picB_prod.Name = "picB_prod";
            this.picB_prod.Size = new System.Drawing.Size(284, 188);
            this.picB_prod.TabIndex = 11;
            this.picB_prod.TabStop = false;
            // 
            // Form_prod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(667, 473);
            this.Controls.Add(this.btt_sld);
            this.Controls.Add(this.btt_car);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_prod";
            this.Text = "Productos Zapateria UMI";
            this.Load += new System.EventHandler(this.Form_prod_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picB_prod)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbB_Prod;
        private System.Windows.Forms.ComboBox cmbB_zse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btt_car;
        private System.Windows.Forms.Button btt_sld;
        private System.Windows.Forms.RadioButton rdoB_C;
        private System.Windows.Forms.RadioButton rdoB_D;
        private System.Windows.Forms.ComboBox cmbB_clr;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picB_prod;
    }
}