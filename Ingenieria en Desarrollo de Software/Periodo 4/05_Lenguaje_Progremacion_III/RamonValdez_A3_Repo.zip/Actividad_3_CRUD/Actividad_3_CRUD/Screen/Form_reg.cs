﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD.Screen
{
    public partial class Form_reg : Form
    {
        public Form_reg()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btt_add_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                //    SqlCommand cmd = new SqlCommand("Insert into cliente(id_cliente, nombre, apellido, fec_nac, telefono, email) values ('" + txtB_ID +"', '"+ txtB_Nom +"', '"+ txtB_ape + "', '"+ txtB_fenac +"', '"+ txtB_pho +"', '"+ txtB_email +"')", cn);
                //    cmd.CommandType = CommandType.Text;
                cn.Open();
                if (string.IsNullOrWhiteSpace(txtB_Nom.Text) ||
                    string.IsNullOrWhiteSpace(txtB_ape.Text) ||
                    string.IsNullOrWhiteSpace(txtB_fenac.Text) ||
                    string.IsNullOrWhiteSpace(txtB_pho.Text) ||
                    string.IsNullOrWhiteSpace(txtB_email.Text))
                {
                    MessageBox.Show("Todos los campos son obligatorios para el alta del cliente.", "Operación incorrecta");
                }
                else
                {
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO cliente (nombre, apellido, fec_nac, telefono, email) VALUES (@nombre, @apellido, @fec_nac, @telefono, @email)", cn))
                    {
                        cmd.CommandType = CommandType.Text;

                        // Add parameters to the command
                        //cmd.Parameters.AddWithValue("@id_cliente", txtB_ID.Text);
                        cmd.Parameters.AddWithValue("@nombre", txtB_Nom.Text);
                        cmd.Parameters.AddWithValue("@apellido", txtB_ape.Text);
                        cmd.Parameters.AddWithValue("@fec_nac", txtB_fenac.Text);
                        cmd.Parameters.AddWithValue("@telefono", txtB_pho.Text);
                        cmd.Parameters.AddWithValue("@email", txtB_email.Text);
                        cmd.ExecuteNonQuery();

                        txtB_Nom.Text = "";
                        txtB_ape.Text = "";
                        txtB_fenac.Text = "";
                        txtB_pho.Text = "";
                        txtB_email.Text = "";
                        MessageBox.Show("Registro exitoso de cliente nuevo.", "Registro Cliente.");
                    }
                }
            }
        }

        private void btt_sld_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_vw_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from cliente", cn);
                sda.SelectCommand.CommandType = CommandType.Text;
                cn.Open();
                sda.Fill(dt);
                dGV_db.DataSource = dt;
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void btt_elmn_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                cn.Open();

                using (SqlCommand cmd = new SqlCommand("DELETE FROM cliente WHERE id_cliente = @id", cn))
                {
                  cmd.Parameters.AddWithValue("@id", txtB_ID.Text);
                  cmd.CommandType = CommandType.Text;
                
                  int rowsAffected = cmd.ExecuteNonQuery();

                  if (rowsAffected > 0)
                  {
                     MessageBox.Show($"Se eliminó el registro del cliente con el ID: {txtB_ID.Text}", "Éxito");
                  }
                  else
                  {
                     MessageBox.Show("No se encontró ningún cliente con el ID especificado, Usar el capo id.", "Aviso");
                  }
                }
            }
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void btt_edt_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            { 
                cn.Open();

                string id = txtB_ID.Text;
                bool idExists = false;

                using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM cliente WHERE id_cliente = @id", cn))
                {
                    checkCmd.Parameters.AddWithValue("@id", id);
                    int count = (int)checkCmd.ExecuteScalar();
                    idExists = count > 0;
                }

                // Verificar si el ID existe y al menos un campo adicional no está vacío
                if (!idExists ||
                    (string.IsNullOrEmpty(txtB_Nom.Text) &&
                     string.IsNullOrEmpty(txtB_ape.Text) &&
                     string.IsNullOrEmpty(txtB_fenac.Text) &&
                     string.IsNullOrEmpty(txtB_pho.Text) &&
                     string.IsNullOrEmpty(txtB_email.Text)))
                {
                    MessageBox.Show("El ID ingresado no existe o no se proporcionó información adicional para actualizar el registro.", "Error de Validación");
                }
                else
                {
                    // ID existe y al menos un campo adicional no está vacío, proceder con la actualización
                    StringBuilder queryBuilder = new StringBuilder("UPDATE cliente SET ");

                    if (!string.IsNullOrEmpty(txtB_Nom.Text))
                    {
                        queryBuilder.Append("nombre = @nombre, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_ape.Text))
                    {
                        queryBuilder.Append("apellido = @apellido, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_fenac.Text))
                    {
                        queryBuilder.Append("fec_nac = @fec_nac, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_pho.Text))
                    {
                        queryBuilder.Append("telefono = @telefono, ");
                    }
                    if (!string.IsNullOrEmpty(txtB_email.Text))
                    {
                        queryBuilder.Append("email = @email, ");
                    }

                    queryBuilder.Length -= 2;
                    queryBuilder.Append(" WHERE id_cliente = @id");

                    using (SqlCommand cmd = new SqlCommand(queryBuilder.ToString(), cn))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@id", id);
                        if (!string.IsNullOrEmpty(txtB_Nom.Text))
                        {
                            cmd.Parameters.AddWithValue("@nombre", txtB_Nom.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_ape.Text))
                        {
                            cmd.Parameters.AddWithValue("@apellido", txtB_ape.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_fenac.Text))
                        {
                            cmd.Parameters.AddWithValue("@fec_nac", txtB_fenac.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_pho.Text))
                        {
                            cmd.Parameters.AddWithValue("@telefono", txtB_pho.Text);
                        }
                        if (!string.IsNullOrEmpty(txtB_email.Text))
                        {
                            cmd.Parameters.AddWithValue("@email", txtB_email.Text);
                        }
                        cmd.ExecuteNonQuery();
                    }

                    // Vaciar text de update
                    txtB_ID.Text = "";
                    txtB_Nom.Text = "";
                    txtB_ape.Text = "";
                    txtB_fenac.Text = "";
                    txtB_pho.Text = "";
                    txtB_email.Text = "";

                    MessageBox.Show("El registro fue modificado exitosamente.", "Registro Cliente Modificado");
                }

            }


        }
    }
    
}
