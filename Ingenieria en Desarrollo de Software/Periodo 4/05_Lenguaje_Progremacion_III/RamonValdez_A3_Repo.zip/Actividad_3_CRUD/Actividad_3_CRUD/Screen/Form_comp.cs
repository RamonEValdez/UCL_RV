﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Screen
{
    public partial class Form_comp : Form
    {
        public Form_comp()
        {
            InitializeComponent();
        }

        private void btt_sld_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btt_vtas_Click(object sender, EventArgs e)
        {
            string consulta = @"
              WITH MesesConVentas AS (
              SELECT DISTINCT YEAR(fch_comp) AS Año, MONTH(fch_comp) AS Mes
              FROM compras
                )

             SELECT Año, Mes,
               SUM(ctn_pod) AS Productos, FORMAT(SUM(cost_pod), 'C', 'es-MX') AS Compras
             FROM MesesConVentas
             LEFT JOIN compras ON MesesConVentas.Mes = MONTH(fch_comp) AND MesesConVentas.Año = YEAR(fch_comp)
             GROUP BY Año, Mes
             ORDER BY Año, Mes";

            using (SqlConnection cn = new SqlConnection("Data Source=231444L90188024\\SQLEXPRESS;Initial Catalog=DB_LPIII_SQLVS_A3;Persist Security Info=True;User ID=sa;Password=@C0pq3l.2021$;Encrypt=False"))
            {
                try
                {
                    cn.Open();
                    SqlCommand command = new SqlCommand(consulta, cn);
                    SqlDataReader reader = command.ExecuteReader();

                    // Limpiar datos anteriores y definir columnas en el control DataGridView
                    dataGridView1.Columns.Clear();
                    dataGridView1.Columns.Add("Año", "Año");
                    dataGridView1.Columns.Add("Mes", "Mes");
                    dataGridView1.Columns.Add("Productos", "Productos");
                    dataGridView1.Columns.Add("Compras", "Compras");

                    // Limpiar filas anteriores
                    dataGridView1.Rows.Clear();

                    // Leer resultados y agregarlos al control DataGridView
                    while (reader.Read())
                    {
                        // Agregar fila al DataGridView
                        dataGridView1.Rows.Add(
                            reader["Año"].ToString(),
                            reader["Mes"].ToString(),
                            reader["Productos"].ToString(),
                            reader["Compras"].ToString()
                        );
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar las ventas: " + ex.Message);
                }
            }
        }
    }
    
}
