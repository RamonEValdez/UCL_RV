﻿namespace Actividad_3_CRUD.Screen
{
    partial class Form_Reg2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Reg2));
            this.tabCtl_reg = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btt_Elm = new System.Windows.Forms.Button();
            this.btt_sld = new System.Windows.Forms.Button();
            this.btt_vw = new System.Windows.Forms.Button();
            this.btt_mod = new System.Windows.Forms.Button();
            this.btt_add = new System.Windows.Forms.Button();
            this.dGV_pvr = new System.Windows.Forms.DataGridView();
            this.gBox_R2 = new System.Windows.Forms.GroupBox();
            this.lbl_com = new System.Windows.Forms.Label();
            this.txtB_eml = new System.Windows.Forms.TextBox();
            this.txtB_pho = new System.Windows.Forms.TextBox();
            this.txtB_dir = new System.Windows.Forms.TextBox();
            this.txtB_ape = new System.Windows.Forms.TextBox();
            this.txtB_nom = new System.Windows.Forms.TextBox();
            this.txtB_ID = new System.Windows.Forms.TextBox();
            this.lbl_eml = new System.Windows.Forms.Label();
            this.lbl_pho = new System.Windows.Forms.Label();
            this.lbl_dir = new System.Windows.Forms.Label();
            this.lbl_ape = new System.Windows.Forms.Label();
            this.lbl_Nom = new System.Windows.Forms.Label();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btt_elm2 = new System.Windows.Forms.Button();
            this.btt_sld2 = new System.Windows.Forms.Button();
            this.btt_vw2 = new System.Windows.Forms.Button();
            this.btt_mod2 = new System.Windows.Forms.Button();
            this.btt_add2 = new System.Windows.Forms.Button();
            this.dGV_prod = new System.Windows.Forms.DataGridView();
            this.gB_prud = new System.Windows.Forms.GroupBox();
            this.txtB_sto = new System.Windows.Forms.TextBox();
            this.lbl_sto = new System.Windows.Forms.Label();
            this.txtB_id2 = new System.Windows.Forms.TextBox();
            this.txtB_tpo = new System.Windows.Forms.TextBox();
            this.txtB_cst = new System.Windows.Forms.TextBox();
            this.txtB_zse = new System.Windows.Forms.TextBox();
            this.txtB_ctg = new System.Windows.Forms.TextBox();
            this.txtB_mar = new System.Windows.Forms.TextBox();
            this.txtB_pod = new System.Windows.Forms.TextBox();
            this.lbl_tpo = new System.Windows.Forms.Label();
            this.lbl_cost = new System.Windows.Forms.Label();
            this.lbl_tll = new System.Windows.Forms.Label();
            this.lbl_cat = new System.Windows.Forms.Label();
            this.lbl_prod = new System.Windows.Forms.Label();
            this.lbl_mar = new System.Windows.Forms.Label();
            this.lbl_id2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabCtl_reg.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_pvr)).BeginInit();
            this.gBox_R2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGV_prod)).BeginInit();
            this.gB_prud.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCtl_reg
            // 
            this.tabCtl_reg.Controls.Add(this.tabPage1);
            this.tabCtl_reg.Controls.Add(this.tabPage2);
            this.tabCtl_reg.Location = new System.Drawing.Point(-1, -3);
            this.tabCtl_reg.Multiline = true;
            this.tabCtl_reg.Name = "tabCtl_reg";
            this.tabCtl_reg.SelectedIndex = 0;
            this.tabCtl_reg.Size = new System.Drawing.Size(917, 809);
            this.tabCtl_reg.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage1.BackgroundImage")));
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage1.Controls.Add(this.btt_Elm);
            this.tabPage1.Controls.Add(this.btt_sld);
            this.tabPage1.Controls.Add(this.btt_vw);
            this.tabPage1.Controls.Add(this.btt_mod);
            this.tabPage1.Controls.Add(this.btt_add);
            this.tabPage1.Controls.Add(this.dGV_pvr);
            this.tabPage1.Controls.Add(this.gBox_R2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(909, 783);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Proveedor";
            // 
            // btt_Elm
            // 
            this.btt_Elm.BackColor = System.Drawing.Color.Red;
            this.btt_Elm.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_Elm.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_Elm.Location = new System.Drawing.Point(769, 299);
            this.btt_Elm.Name = "btt_Elm";
            this.btt_Elm.Size = new System.Drawing.Size(122, 59);
            this.btt_Elm.TabIndex = 6;
            this.btt_Elm.Text = "Eliminar.";
            this.btt_Elm.UseVisualStyleBackColor = false;
            this.btt_Elm.Click += new System.EventHandler(this.btt_Elm_Click);
            // 
            // btt_sld
            // 
            this.btt_sld.BackColor = System.Drawing.Color.Black;
            this.btt_sld.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_sld.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_sld.Location = new System.Drawing.Point(623, 299);
            this.btt_sld.Name = "btt_sld";
            this.btt_sld.Size = new System.Drawing.Size(122, 59);
            this.btt_sld.TabIndex = 5;
            this.btt_sld.Text = "Salir.";
            this.btt_sld.UseVisualStyleBackColor = false;
            this.btt_sld.Click += new System.EventHandler(this.btt_sld_Click);
            // 
            // btt_vw
            // 
            this.btt_vw.BackColor = System.Drawing.Color.Black;
            this.btt_vw.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_vw.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_vw.Location = new System.Drawing.Point(663, 219);
            this.btt_vw.Name = "btt_vw";
            this.btt_vw.Size = new System.Drawing.Size(180, 51);
            this.btt_vw.TabIndex = 4;
            this.btt_vw.Text = "Mostrar.";
            this.btt_vw.UseVisualStyleBackColor = false;
            this.btt_vw.Click += new System.EventHandler(this.btt_vw_Click);
            // 
            // btt_mod
            // 
            this.btt_mod.BackColor = System.Drawing.Color.Black;
            this.btt_mod.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_mod.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_mod.Location = new System.Drawing.Point(663, 134);
            this.btt_mod.Name = "btt_mod";
            this.btt_mod.Size = new System.Drawing.Size(180, 51);
            this.btt_mod.TabIndex = 3;
            this.btt_mod.Text = "Modificar.";
            this.btt_mod.UseVisualStyleBackColor = false;
            this.btt_mod.Click += new System.EventHandler(this.btt_mod_Click);
            // 
            // btt_add
            // 
            this.btt_add.BackColor = System.Drawing.Color.Black;
            this.btt_add.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_add.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btt_add.Location = new System.Drawing.Point(663, 55);
            this.btt_add.Name = "btt_add";
            this.btt_add.Size = new System.Drawing.Size(180, 51);
            this.btt_add.TabIndex = 2;
            this.btt_add.Text = "Alta.";
            this.btt_add.UseVisualStyleBackColor = false;
            this.btt_add.Click += new System.EventHandler(this.btt_add_Click);
            // 
            // dGV_pvr
            // 
            this.dGV_pvr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_pvr.Location = new System.Drawing.Point(26, 530);
            this.dGV_pvr.Name = "dGV_pvr";
            this.dGV_pvr.Size = new System.Drawing.Size(731, 185);
            this.dGV_pvr.TabIndex = 1;
            // 
            // gBox_R2
            // 
            this.gBox_R2.Controls.Add(this.lbl_com);
            this.gBox_R2.Controls.Add(this.txtB_eml);
            this.gBox_R2.Controls.Add(this.txtB_pho);
            this.gBox_R2.Controls.Add(this.txtB_dir);
            this.gBox_R2.Controls.Add(this.txtB_ape);
            this.gBox_R2.Controls.Add(this.txtB_nom);
            this.gBox_R2.Controls.Add(this.txtB_ID);
            this.gBox_R2.Controls.Add(this.lbl_eml);
            this.gBox_R2.Controls.Add(this.lbl_pho);
            this.gBox_R2.Controls.Add(this.lbl_dir);
            this.gBox_R2.Controls.Add(this.lbl_ape);
            this.gBox_R2.Controls.Add(this.lbl_Nom);
            this.gBox_R2.Controls.Add(this.lbl_ID);
            this.gBox_R2.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gBox_R2.Location = new System.Drawing.Point(26, 18);
            this.gBox_R2.Name = "gBox_R2";
            this.gBox_R2.Size = new System.Drawing.Size(573, 478);
            this.gBox_R2.TabIndex = 0;
            this.gBox_R2.TabStop = false;
            this.gBox_R2.Text = "Registro Proveedor";
            // 
            // lbl_com
            // 
            this.lbl_com.AutoSize = true;
            this.lbl_com.BackColor = System.Drawing.Color.Transparent;
            this.lbl_com.Font = new System.Drawing.Font("Calibri", 15.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.lbl_com.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_com.Location = new System.Drawing.Point(192, 411);
            this.lbl_com.Name = "lbl_com";
            this.lbl_com.Size = new System.Drawing.Size(359, 52);
            this.lbl_com.TabIndex = 12;
            this.lbl_com.Text = "El uso del compa  ID es solamente  para \r\nbajas o algun cambio de registro.\r\n";
            // 
            // txtB_eml
            // 
            this.txtB_eml.Location = new System.Drawing.Point(222, 342);
            this.txtB_eml.Name = "txtB_eml";
            this.txtB_eml.Size = new System.Drawing.Size(290, 40);
            this.txtB_eml.TabIndex = 11;
            // 
            // txtB_pho
            // 
            this.txtB_pho.Location = new System.Drawing.Point(222, 281);
            this.txtB_pho.Name = "txtB_pho";
            this.txtB_pho.Size = new System.Drawing.Size(290, 40);
            this.txtB_pho.TabIndex = 10;
            // 
            // txtB_dir
            // 
            this.txtB_dir.Location = new System.Drawing.Point(222, 180);
            this.txtB_dir.Multiline = true;
            this.txtB_dir.Name = "txtB_dir";
            this.txtB_dir.Size = new System.Drawing.Size(290, 72);
            this.txtB_dir.TabIndex = 9;
            // 
            // txtB_ape
            // 
            this.txtB_ape.Location = new System.Drawing.Point(222, 116);
            this.txtB_ape.Name = "txtB_ape";
            this.txtB_ape.Size = new System.Drawing.Size(290, 40);
            this.txtB_ape.TabIndex = 8;
            // 
            // txtB_nom
            // 
            this.txtB_nom.Location = new System.Drawing.Point(222, 48);
            this.txtB_nom.Name = "txtB_nom";
            this.txtB_nom.Size = new System.Drawing.Size(290, 40);
            this.txtB_nom.TabIndex = 7;
            // 
            // txtB_ID
            // 
            this.txtB_ID.Location = new System.Drawing.Point(93, 419);
            this.txtB_ID.Name = "txtB_ID";
            this.txtB_ID.Size = new System.Drawing.Size(93, 40);
            this.txtB_ID.TabIndex = 6;
            // 
            // lbl_eml
            // 
            this.lbl_eml.AutoSize = true;
            this.lbl_eml.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_eml.Location = new System.Drawing.Point(33, 342);
            this.lbl_eml.Name = "lbl_eml";
            this.lbl_eml.Size = new System.Drawing.Size(98, 36);
            this.lbl_eml.TabIndex = 5;
            this.lbl_eml.Text = "E-Mail:";
            // 
            // lbl_pho
            // 
            this.lbl_pho.AutoSize = true;
            this.lbl_pho.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pho.Location = new System.Drawing.Point(33, 281);
            this.lbl_pho.Name = "lbl_pho";
            this.lbl_pho.Size = new System.Drawing.Size(128, 36);
            this.lbl_pho.TabIndex = 4;
            this.lbl_pho.Text = "Telefono:";
            // 
            // lbl_dir
            // 
            this.lbl_dir.AutoSize = true;
            this.lbl_dir.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dir.Location = new System.Drawing.Point(25, 180);
            this.lbl_dir.Name = "lbl_dir";
            this.lbl_dir.Size = new System.Drawing.Size(136, 36);
            this.lbl_dir.TabIndex = 3;
            this.lbl_dir.Text = "Direccion:";
            // 
            // lbl_ape
            // 
            this.lbl_ape.AutoSize = true;
            this.lbl_ape.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ape.Location = new System.Drawing.Point(25, 116);
            this.lbl_ape.Name = "lbl_ape";
            this.lbl_ape.Size = new System.Drawing.Size(155, 36);
            this.lbl_ape.TabIndex = 2;
            this.lbl_ape.Text = "Apellido(s):";
            // 
            // lbl_Nom
            // 
            this.lbl_Nom.AutoSize = true;
            this.lbl_Nom.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nom.Location = new System.Drawing.Point(25, 48);
            this.lbl_Nom.Name = "lbl_Nom";
            this.lbl_Nom.Size = new System.Drawing.Size(153, 36);
            this.lbl_Nom.TabIndex = 1;
            this.lbl_Nom.Text = "Nombre(s):";
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(33, 420);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(49, 36);
            this.lbl_ID.TabIndex = 0;
            this.lbl_ID.Text = "ID:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage2.BackgroundImage")));
            this.tabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage2.Controls.Add(this.btt_elm2);
            this.tabPage2.Controls.Add(this.btt_sld2);
            this.tabPage2.Controls.Add(this.btt_vw2);
            this.tabPage2.Controls.Add(this.btt_mod2);
            this.tabPage2.Controls.Add(this.btt_add2);
            this.tabPage2.Controls.Add(this.dGV_prod);
            this.tabPage2.Controls.Add(this.gB_prud);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(909, 783);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Productos";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btt_elm2
            // 
            this.btt_elm2.BackColor = System.Drawing.Color.Red;
            this.btt_elm2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_elm2.ForeColor = System.Drawing.SystemColors.Control;
            this.btt_elm2.Location = new System.Drawing.Point(633, 410);
            this.btt_elm2.Name = "btt_elm2";
            this.btt_elm2.Size = new System.Drawing.Size(217, 62);
            this.btt_elm2.TabIndex = 6;
            this.btt_elm2.Text = "Baja.";
            this.btt_elm2.UseVisualStyleBackColor = false;
            this.btt_elm2.Click += new System.EventHandler(this.btt_elm2_Click);
            // 
            // btt_sld2
            // 
            this.btt_sld2.BackColor = System.Drawing.Color.Black;
            this.btt_sld2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_sld2.ForeColor = System.Drawing.SystemColors.Control;
            this.btt_sld2.Location = new System.Drawing.Point(633, 317);
            this.btt_sld2.Name = "btt_sld2";
            this.btt_sld2.Size = new System.Drawing.Size(217, 62);
            this.btt_sld2.TabIndex = 5;
            this.btt_sld2.Text = "Cerrar.";
            this.btt_sld2.UseVisualStyleBackColor = false;
            this.btt_sld2.Click += new System.EventHandler(this.btt_sld2_Click);
            // 
            // btt_vw2
            // 
            this.btt_vw2.BackColor = System.Drawing.Color.Black;
            this.btt_vw2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_vw2.ForeColor = System.Drawing.SystemColors.Control;
            this.btt_vw2.Location = new System.Drawing.Point(633, 229);
            this.btt_vw2.Name = "btt_vw2";
            this.btt_vw2.Size = new System.Drawing.Size(217, 62);
            this.btt_vw2.TabIndex = 4;
            this.btt_vw2.Text = "Ver.";
            this.btt_vw2.UseVisualStyleBackColor = false;
            this.btt_vw2.Click += new System.EventHandler(this.btt_vw2_Click);
            // 
            // btt_mod2
            // 
            this.btt_mod2.BackColor = System.Drawing.Color.Black;
            this.btt_mod2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_mod2.ForeColor = System.Drawing.SystemColors.Control;
            this.btt_mod2.Location = new System.Drawing.Point(633, 141);
            this.btt_mod2.Name = "btt_mod2";
            this.btt_mod2.Size = new System.Drawing.Size(217, 62);
            this.btt_mod2.TabIndex = 3;
            this.btt_mod2.Text = "Cambio.";
            this.btt_mod2.UseVisualStyleBackColor = false;
            this.btt_mod2.Click += new System.EventHandler(this.btt_mod2_Click);
            // 
            // btt_add2
            // 
            this.btt_add2.BackColor = System.Drawing.Color.Black;
            this.btt_add2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_add2.ForeColor = System.Drawing.SystemColors.Control;
            this.btt_add2.Location = new System.Drawing.Point(633, 48);
            this.btt_add2.Name = "btt_add2";
            this.btt_add2.Size = new System.Drawing.Size(217, 62);
            this.btt_add2.TabIndex = 2;
            this.btt_add2.Text = "Alta.";
            this.btt_add2.UseVisualStyleBackColor = false;
            this.btt_add2.Click += new System.EventHandler(this.btt_add2_Click);
            // 
            // dGV_prod
            // 
            this.dGV_prod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGV_prod.Location = new System.Drawing.Point(9, 568);
            this.dGV_prod.Name = "dGV_prod";
            this.dGV_prod.Size = new System.Drawing.Size(779, 186);
            this.dGV_prod.TabIndex = 1;
            // 
            // gB_prud
            // 
            this.gB_prud.Controls.Add(this.label1);
            this.gB_prud.Controls.Add(this.txtB_sto);
            this.gB_prud.Controls.Add(this.lbl_sto);
            this.gB_prud.Controls.Add(this.txtB_id2);
            this.gB_prud.Controls.Add(this.txtB_tpo);
            this.gB_prud.Controls.Add(this.txtB_cst);
            this.gB_prud.Controls.Add(this.txtB_zse);
            this.gB_prud.Controls.Add(this.txtB_ctg);
            this.gB_prud.Controls.Add(this.txtB_mar);
            this.gB_prud.Controls.Add(this.txtB_pod);
            this.gB_prud.Controls.Add(this.lbl_tpo);
            this.gB_prud.Controls.Add(this.lbl_cost);
            this.gB_prud.Controls.Add(this.lbl_tll);
            this.gB_prud.Controls.Add(this.lbl_cat);
            this.gB_prud.Controls.Add(this.lbl_prod);
            this.gB_prud.Controls.Add(this.lbl_mar);
            this.gB_prud.Controls.Add(this.lbl_id2);
            this.gB_prud.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gB_prud.Location = new System.Drawing.Point(3, 6);
            this.gB_prud.Name = "gB_prud";
            this.gB_prud.Size = new System.Drawing.Size(578, 538);
            this.gB_prud.TabIndex = 0;
            this.gB_prud.TabStop = false;
            this.gB_prud.Text = "Registro Productos";
            // 
            // txtB_sto
            // 
            this.txtB_sto.Location = new System.Drawing.Point(234, 404);
            this.txtB_sto.Name = "txtB_sto";
            this.txtB_sto.Size = new System.Drawing.Size(271, 40);
            this.txtB_sto.TabIndex = 15;
            // 
            // lbl_sto
            // 
            this.lbl_sto.AutoSize = true;
            this.lbl_sto.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sto.Location = new System.Drawing.Point(32, 404);
            this.lbl_sto.Name = "lbl_sto";
            this.lbl_sto.Size = new System.Drawing.Size(83, 33);
            this.lbl_sto.TabIndex = 14;
            this.lbl_sto.Text = "Stock:";
            this.lbl_sto.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtB_id2
            // 
            this.txtB_id2.Location = new System.Drawing.Point(107, 465);
            this.txtB_id2.Name = "txtB_id2";
            this.txtB_id2.Size = new System.Drawing.Size(109, 40);
            this.txtB_id2.TabIndex = 13;
            // 
            // txtB_tpo
            // 
            this.txtB_tpo.Location = new System.Drawing.Point(234, 341);
            this.txtB_tpo.Name = "txtB_tpo";
            this.txtB_tpo.Size = new System.Drawing.Size(271, 40);
            this.txtB_tpo.TabIndex = 12;
            // 
            // txtB_cst
            // 
            this.txtB_cst.Location = new System.Drawing.Point(234, 276);
            this.txtB_cst.Name = "txtB_cst";
            this.txtB_cst.Size = new System.Drawing.Size(271, 40);
            this.txtB_cst.TabIndex = 11;
            // 
            // txtB_zse
            // 
            this.txtB_zse.Location = new System.Drawing.Point(234, 213);
            this.txtB_zse.Name = "txtB_zse";
            this.txtB_zse.Size = new System.Drawing.Size(271, 40);
            this.txtB_zse.TabIndex = 10;
            // 
            // txtB_ctg
            // 
            this.txtB_ctg.Location = new System.Drawing.Point(234, 151);
            this.txtB_ctg.Name = "txtB_ctg";
            this.txtB_ctg.Size = new System.Drawing.Size(271, 40);
            this.txtB_ctg.TabIndex = 9;
            // 
            // txtB_mar
            // 
            this.txtB_mar.Location = new System.Drawing.Point(234, 94);
            this.txtB_mar.Name = "txtB_mar";
            this.txtB_mar.Size = new System.Drawing.Size(271, 40);
            this.txtB_mar.TabIndex = 8;
            // 
            // txtB_pod
            // 
            this.txtB_pod.Location = new System.Drawing.Point(234, 38);
            this.txtB_pod.Name = "txtB_pod";
            this.txtB_pod.Size = new System.Drawing.Size(271, 40);
            this.txtB_pod.TabIndex = 7;
            // 
            // lbl_tpo
            // 
            this.lbl_tpo.AutoSize = true;
            this.lbl_tpo.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tpo.Location = new System.Drawing.Point(34, 348);
            this.lbl_tpo.Name = "lbl_tpo";
            this.lbl_tpo.Size = new System.Drawing.Size(71, 33);
            this.lbl_tpo.TabIndex = 6;
            this.lbl_tpo.Text = "Tipo:";
            // 
            // lbl_cost
            // 
            this.lbl_cost.AutoSize = true;
            this.lbl_cost.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cost.Location = new System.Drawing.Point(32, 283);
            this.lbl_cost.Name = "lbl_cost";
            this.lbl_cost.Size = new System.Drawing.Size(86, 33);
            this.lbl_cost.TabIndex = 5;
            this.lbl_cost.Text = "Costo:";
            // 
            // lbl_tll
            // 
            this.lbl_tll.AutoSize = true;
            this.lbl_tll.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tll.Location = new System.Drawing.Point(32, 220);
            this.lbl_tll.Name = "lbl_tll";
            this.lbl_tll.Size = new System.Drawing.Size(73, 33);
            this.lbl_tll.TabIndex = 4;
            this.lbl_tll.Text = "Talla:";
            // 
            // lbl_cat
            // 
            this.lbl_cat.AutoSize = true;
            this.lbl_cat.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cat.Location = new System.Drawing.Point(32, 158);
            this.lbl_cat.Name = "lbl_cat";
            this.lbl_cat.Size = new System.Drawing.Size(130, 33);
            this.lbl_cat.TabIndex = 3;
            this.lbl_cat.Text = "Categoria:";
            // 
            // lbl_prod
            // 
            this.lbl_prod.AutoSize = true;
            this.lbl_prod.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prod.Location = new System.Drawing.Point(32, 38);
            this.lbl_prod.Name = "lbl_prod";
            this.lbl_prod.Size = new System.Drawing.Size(124, 33);
            this.lbl_prod.TabIndex = 2;
            this.lbl_prod.Text = "Producto:";
            // 
            // lbl_mar
            // 
            this.lbl_mar.AutoSize = true;
            this.lbl_mar.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mar.Location = new System.Drawing.Point(32, 94);
            this.lbl_mar.Name = "lbl_mar";
            this.lbl_mar.Size = new System.Drawing.Size(93, 33);
            this.lbl_mar.TabIndex = 1;
            this.lbl_mar.Text = "Marca:";
            // 
            // lbl_id2
            // 
            this.lbl_id2.AutoSize = true;
            this.lbl_id2.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_id2.Location = new System.Drawing.Point(34, 465);
            this.lbl_id2.Name = "lbl_id2";
            this.lbl_id2.Size = new System.Drawing.Size(46, 33);
            this.lbl_id2.TabIndex = 0;
            this.lbl_id2.Text = "ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(222, 459);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(326, 52);
            this.label1.TabIndex = 16;
            this.label1.Text = "El uso del campo ID se utiliza con los\r\n botones de baja y cambios.";
            // 
            // Form_Reg2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(915, 803);
            this.Controls.Add(this.tabCtl_reg);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_Reg2";
            this.Text = "Registros";
            this.Load += new System.EventHandler(this.Form_Reg2_Load);
            this.tabCtl_reg.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_pvr)).EndInit();
            this.gBox_R2.ResumeLayout(false);
            this.gBox_R2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGV_prod)).EndInit();
            this.gB_prud.ResumeLayout(false);
            this.gB_prud.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtl_reg;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gBox_R2;
        private System.Windows.Forms.DataGridView dGV_pvr;
        private System.Windows.Forms.Button btt_mod;
        private System.Windows.Forms.Button btt_add;
        private System.Windows.Forms.Button btt_vw;
        private System.Windows.Forms.Button btt_Elm;
        private System.Windows.Forms.Button btt_sld;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.Label lbl_eml;
        private System.Windows.Forms.Label lbl_pho;
        private System.Windows.Forms.Label lbl_dir;
        private System.Windows.Forms.Label lbl_ape;
        private System.Windows.Forms.Label lbl_Nom;
        private System.Windows.Forms.TextBox txtB_pho;
        private System.Windows.Forms.TextBox txtB_dir;
        private System.Windows.Forms.TextBox txtB_ape;
        private System.Windows.Forms.TextBox txtB_nom;
        private System.Windows.Forms.TextBox txtB_ID;
        private System.Windows.Forms.TextBox txtB_eml;
        private System.Windows.Forms.Label lbl_com;
        private System.Windows.Forms.GroupBox gB_prud;
        private System.Windows.Forms.Label lbl_id2;
        private System.Windows.Forms.Label lbl_prod;
        private System.Windows.Forms.Label lbl_mar;
        private System.Windows.Forms.Label lbl_tll;
        private System.Windows.Forms.Label lbl_cat;
        private System.Windows.Forms.Label lbl_cost;
        private System.Windows.Forms.Label lbl_tpo;
        private System.Windows.Forms.TextBox txtB_id2;
        private System.Windows.Forms.TextBox txtB_tpo;
        private System.Windows.Forms.TextBox txtB_cst;
        private System.Windows.Forms.TextBox txtB_zse;
        private System.Windows.Forms.TextBox txtB_ctg;
        private System.Windows.Forms.TextBox txtB_mar;
        private System.Windows.Forms.TextBox txtB_pod;
        private System.Windows.Forms.Button btt_mod2;
        private System.Windows.Forms.Button btt_add2;
        private System.Windows.Forms.DataGridView dGV_prod;
        private System.Windows.Forms.Button btt_elm2;
        private System.Windows.Forms.Button btt_sld2;
        private System.Windows.Forms.Button btt_vw2;
        private System.Windows.Forms.TextBox txtB_sto;
        private System.Windows.Forms.Label lbl_sto;
        private System.Windows.Forms.Label label1;
    }
}