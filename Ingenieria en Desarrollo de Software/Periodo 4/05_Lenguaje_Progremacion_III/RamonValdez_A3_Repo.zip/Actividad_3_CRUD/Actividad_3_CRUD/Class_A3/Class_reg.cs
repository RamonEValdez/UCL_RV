﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_3_CRUD.Class_A3
{
    public class Class_reg
    {
    }
}
