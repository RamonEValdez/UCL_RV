﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_3_CRUD.Class_A3
{
    public class Class_bnv
    {
        public string hola ()
        {
          string hla;
            hla = "Hola bienvenidos a Zapateria UMI donde encontraras tu calzado favorito, mejores diseño y promociones grandiosas";
          return hla;
        }
        public string vicion()
        {
            string vcn;
            vcn = "Ser una organización que suministre calzado casual, seguridad industrial y escolar con calidad, eficiencia y competitividad, para satisfacer las necesidades de nuestros clientes en el mercado nacional. Contribuimos con la construcción de un mejor país, minimizando la afectación del medio ambiente y creando principios de responsabilidad social.";
            return vcn;
        }
        public string mision()
        {
            string misn;
            misn = "Venta de calzado casual, deportivo e industrial, que cumpla con estándares de calidad nacional e internacional, velando por satisfacer las necesidades del mercado. Ofrecer un ambiente de trabajo agradable y proporcionar nuevas oportunidades para mejorar la calidad de vida de nuestros colaboradores y, en consecuencia, de sus familias. De esta manera, contribuimos al desarrollo del país.";
            return misn;
        }
        public string quien()
        {
            string qsmos;
            qsmos = "Nosotros somos una organización comprometida con la excelencia en el suministro de calzado casual, seguridad industrial y escolar. Nuestra dedicación radica en ofrecer productos de calidad, eficientes y competitivos que satisfagan las necesidades de nuestros clientes en el mercado nacional. Más allá de ser simplemente proveedores, nos consideramos agentes de cambio, contribuyendo a la construcción de un país mejor mediante la minimización de la afectación al medio ambiente y la promoción de principios de responsabilidad social en todas nuestras actividades. En resumen, somos una empresa enfocada en ofrecer soluciones integrales que impacten de manera positiva en la sociedad y en el entorno en el que operamos.";
            return qsmos;
        }
    }
}
