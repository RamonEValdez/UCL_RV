﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD
{
    public partial class Zapateria_UMIA3 : Form
    {
        public Zapateria_UMIA3()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            Class_A3.Class_bnv cls_vcn = new Class_A3.Class_bnv();
            string vcn = cls_vcn.vicion();
            MessageBox.Show(vcn, "Vision Zapateria UNI");
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {

        }

        private void MItm_Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MItm_bvd_Click(object sender, EventArgs e)
        {
            Class_A3.Class_bnv cls_hl = new Class_A3.Class_bnv();
            string hla = cls_hl.hola(); 
            MessageBox.Show(hla, "Bienvenida Zapatera UMI");
        }

        private void MItm_Mision_Click(object sender, EventArgs e)
        {
            Class_A3.Class_bnv cls_msn = new Class_A3.Class_bnv();
            string misn = cls_msn.mision();
            MessageBox.Show(misn, "Mision Zapateria UMI");
        }

        private void MItm_quien_Click(object sender, EventArgs e)
        {
            Class_A3.Class_bnv cls_qsms = new Class_A3.Class_bnv();
            string qsms = cls_qsms.quien();
            MessageBox.Show(qsms, "¿Quienes Somos?");
        }

        private void MItm_Reg_Click(object sender, EventArgs e)
        {

        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Screen.Form_reg form_Reg = new Screen.Form_reg();
            form_Reg.Show();
        }

        private void proveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Screen.Form_Reg2 form_Reg = new Screen.Form_Reg2();

            // Buscar el TabControl por su nombre
            TabControl tabControl = form_Reg.Controls.Find("tabCtl_reg", true).FirstOrDefault() as TabControl;

            if (tabControl != null)
            {
                //tabControl.SelectTab("Proveedor");
                tabControl.SelectedIndex = 0;
            }

            // Mostrar el formulario Form_Reg2
            form_Reg.Show();
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Screen.Form_Reg2 form_Reg = new Screen.Form_Reg2();

            // Buscar el TabControl por su nombre
            TabControl tabControl = form_Reg.Controls.Find("tabCtl_reg", true).FirstOrDefault() as TabControl;

            if (tabControl != null)
            {
                //tabControl.SelectTab("Proveedor");
                tabControl.SelectedIndex = 1;
            }

            // Mostrar el formulario Form_Reg2
            form_Reg.Show();
        }

        private void catalogoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Screen.Form_prod form_prod2 = new Screen.Form_prod();
            form_prod2.Show();
        }

        private void MItm_Comp_Click(object sender, EventArgs e)
        {
            Screen.Form_comp form_comp = new Screen.Form_comp();
            form_comp.Show();
        }
    }
}
