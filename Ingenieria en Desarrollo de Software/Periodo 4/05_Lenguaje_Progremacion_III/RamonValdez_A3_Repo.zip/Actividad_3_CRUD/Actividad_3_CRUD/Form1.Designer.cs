﻿namespace Actividad_3_CRUD
{
    partial class Zapateria_UMIA3
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zapateria_UMIA3));
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MItm_mzap = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_Reg = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proveedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_Comp = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.M_Bienv = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_bvd = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_quien = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_Mision = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_vision = new System.Windows.Forms.ToolStripMenuItem();
            this.MItm_Salir = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 70);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem1.Text = "toolStripMenuItem1";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem2.Text = "toolStripMenuItem2";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(180, 22);
            this.toolStripMenuItem3.Text = "toolStripMenuItem3";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MItm_mzap,
            this.M_Bienv,
            this.MItm_Salir});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MItm_mzap
            // 
            this.MItm_mzap.BackColor = System.Drawing.Color.DarkCyan;
            this.MItm_mzap.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MItm_Reg,
            this.catalogoToolStripMenuItem,
            this.MItm_Comp});
            this.MItm_mzap.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_mzap.Name = "MItm_mzap";
            this.MItm_mzap.Size = new System.Drawing.Size(105, 20);
            this.MItm_mzap.Text = "Menu Zapateria";
            this.MItm_mzap.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // MItm_Reg
            // 
            this.MItm_Reg.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientesToolStripMenuItem,
            this.proveedorToolStripMenuItem,
            this.productosToolStripMenuItem});
            this.MItm_Reg.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_Reg.Name = "MItm_Reg";
            this.MItm_Reg.Size = new System.Drawing.Size(180, 22);
            this.MItm_Reg.Text = "Registros";
            this.MItm_Reg.Click += new System.EventHandler(this.MItm_Reg_Click);
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.clientesToolStripMenuItem.Text = "Clientes.";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // proveedorToolStripMenuItem
            // 
            this.proveedorToolStripMenuItem.Name = "proveedorToolStripMenuItem";
            this.proveedorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.proveedorToolStripMenuItem.Text = "Proveedor.";
            this.proveedorToolStripMenuItem.Click += new System.EventHandler(this.proveedorToolStripMenuItem_Click);
            // 
            // productosToolStripMenuItem
            // 
            this.productosToolStripMenuItem.Name = "productosToolStripMenuItem";
            this.productosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.productosToolStripMenuItem.Text = "Productos.";
            this.productosToolStripMenuItem.Click += new System.EventHandler(this.productosToolStripMenuItem_Click);
            // 
            // MItm_Comp
            // 
            this.MItm_Comp.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_Comp.Name = "MItm_Comp";
            this.MItm_Comp.Size = new System.Drawing.Size(180, 22);
            this.MItm_Comp.Text = "Reportes Ventas.";
            this.MItm_Comp.Click += new System.EventHandler(this.MItm_Comp_Click);
            // 
            // catalogoToolStripMenuItem
            // 
            this.catalogoToolStripMenuItem.Name = "catalogoToolStripMenuItem";
            this.catalogoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.catalogoToolStripMenuItem.Text = "Catalogo.";
            this.catalogoToolStripMenuItem.Click += new System.EventHandler(this.catalogoToolStripMenuItem_Click);
            // 
            // M_Bienv
            // 
            this.M_Bienv.BackColor = System.Drawing.Color.DarkCyan;
            this.M_Bienv.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MItm_bvd,
            this.MItm_quien,
            this.MItm_Mision,
            this.MItm_vision});
            this.M_Bienv.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M_Bienv.Name = "M_Bienv";
            this.M_Bienv.Size = new System.Drawing.Size(79, 20);
            this.M_Bienv.Text = "Bienvenida";
            // 
            // MItm_bvd
            // 
            this.MItm_bvd.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_bvd.Name = "MItm_bvd";
            this.MItm_bvd.Size = new System.Drawing.Size(170, 22);
            this.MItm_bvd.Text = "Hola";
            this.MItm_bvd.Click += new System.EventHandler(this.MItm_bvd_Click);
            // 
            // MItm_quien
            // 
            this.MItm_quien.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_quien.Name = "MItm_quien";
            this.MItm_quien.Size = new System.Drawing.Size(170, 22);
            this.MItm_quien.Text = "¿Quienes Somos?";
            this.MItm_quien.Click += new System.EventHandler(this.MItm_quien_Click);
            // 
            // MItm_Mision
            // 
            this.MItm_Mision.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_Mision.Name = "MItm_Mision";
            this.MItm_Mision.Size = new System.Drawing.Size(170, 22);
            this.MItm_Mision.Text = "Mision";
            this.MItm_Mision.Click += new System.EventHandler(this.MItm_Mision_Click);
            // 
            // MItm_vision
            // 
            this.MItm_vision.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_vision.Name = "MItm_vision";
            this.MItm_vision.Size = new System.Drawing.Size(170, 22);
            this.MItm_vision.Text = "Vision";
            this.MItm_vision.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // MItm_Salir
            // 
            this.MItm_Salir.BackColor = System.Drawing.Color.DarkCyan;
            this.MItm_Salir.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MItm_Salir.Name = "MItm_Salir";
            this.MItm_Salir.Size = new System.Drawing.Size(50, 20);
            this.MItm_Salir.Text = "Salida";
            this.MItm_Salir.Click += new System.EventHandler(this.MItm_Salir_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(150, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 67);
            this.label1.TabIndex = 2;
            this.label1.Text = "ZAPATERIA UMI";
            // 
            // Zapateria_UMIA3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(784, 493);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Zapateria_UMIA3";
            this.Text = "Zapateria UMI A3";
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MItm_mzap;
        private System.Windows.Forms.ToolStripMenuItem MItm_Reg;
        private System.Windows.Forms.ToolStripMenuItem MItm_Comp;
        private System.Windows.Forms.ToolStripMenuItem M_Bienv;
        private System.Windows.Forms.ToolStripMenuItem MItm_Mision;
        private System.Windows.Forms.ToolStripMenuItem MItm_vision;
        private System.Windows.Forms.ToolStripMenuItem MItm_quien;
        private System.Windows.Forms.ToolStripMenuItem MItm_Salir;
        private System.Windows.Forms.ToolStripMenuItem MItm_bvd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem proveedorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catalogoToolStripMenuItem;
    }
}

