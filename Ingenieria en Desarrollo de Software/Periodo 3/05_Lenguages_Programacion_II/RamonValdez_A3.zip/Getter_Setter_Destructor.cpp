// Getter_Setter_Destructor.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//Actividad 3"Final" Lenguajes de la Progrmacion II
//IDS_REVF

#include <iostream>
#include <string>
using namespace std;

class Persona {
private:
    string Nombre;
    int Edad;

public:
    Persona();
    virtual void setPersona(string, int);
    string getNombre();
    int getEdad();
    virtual ~Persona();
};

class Alumno : public Persona {
private:
    float CalFinal;
    string Nivel;

public:
    Alumno();
    void setAlumno(string, int, float, string);
    float getCalFinal();
    string getNivel();
    ~Alumno();
};

class Maestro : public Persona {
private:
    string Materia;

public:
    Maestro();
    void setMaestro(string, int, string);
    string getMateria();
    ~Maestro();
};

class Rector : public Persona {
private:
    string Uni;

public:
    Rector();
    void setRector(string, int, string);
    string getUni();
    ~Rector();
};

Persona::Persona() {
}//Constructor Persona

void Persona::setPersona(string _Nom, int _Edad) {
    Nombre = _Nom;
    Edad = _Edad;
}

string Persona::getNombre() {
    return Nombre;
}

int Persona::getEdad() {
    return Edad;
}

Persona::~Persona() {}//Destructor

Alumno::Alumno() {
}//Constructor Alumno

void Alumno::setAlumno(string _Nom, int _Edad, float _CalFin, string _Nvl) {
    CalFinal = _CalFin;
    Nivel = _Nvl;
}

float Alumno::getCalFinal() {
    return CalFinal;
}

string Alumno::getNivel() {
    return Nivel;
}

Alumno::~Alumno() {}//Destructor

Maestro::Maestro() {
}//Constructor Maestro

void Maestro::setMaestro(string _Nom, int _Edad, string _Materia) {
    Materia = _Materia;
}

string Maestro::getMateria() {
    return Materia;
}

Maestro::~Maestro() {}//Destructor

Rector::Rector() {
}//Constructor Maestro

void Rector::setRector(string _Nom, int _Edad, string _Uni) {
     Uni = _Uni;
}

string Rector::getUni() {
    return Uni;
}

Rector::~Rector() {}//Destructor

int main() {

    Persona Prn0, Prn1, Prn2, Prn3;
    Alumno Almn;
    Maestro Mst;
    Rector Rtr;

   //Prn0.setPersona("Prueba Nombre", 1);
    //cout << "\tNombre: " << Prn0.getNombre() << endl;
    //cout << "\tEdad: " << Prn0.getEdad() << endl;
    //cout << "\n";
      

   Prn1.setPersona("Angela Duarte", 19);
   Almn.setAlumno("Angela Duarte", 19, 80, "Primer Grado");
    cout << "\tNombre de Alumno: " << Prn1.getNombre() << endl;
    cout << "\tEdad: " << Prn1.getEdad() << endl;
    cout << "\tCalificacion Final: " << Almn.getCalFinal() << endl;
    cout << "\tNivel Escolar: " << Almn.getNivel() << endl;
    cout << "\n";

   Prn2.setPersona("Jaime Zapata", 35);
   Mst.setMaestro("Jaime Zapata", 35, "Programacion C++");
    cout << "\tNombre de Maestro: " << Prn2.getNombre() << endl;
    cout << "\tEdad: " << Prn2.getEdad() << endl;
    cout << "\tMateria Impartida: " << Mst.getMateria() << endl;
    cout << "\n";

   Prn3.setPersona("Dulce Lopez", 40);
   Rtr.setRector("Dulce Lopez", 40, "UMI Coppel");
    cout << "\tNombre del Rector Escolar: " << Prn3.getNombre() << endl;
    cout << "\tEdad: " << Prn3.getEdad() << endl;
    cout << "\tUniversidad Asignada: " << Rtr.getUni() << endl;
    cout << "\n";


   return 0;
}