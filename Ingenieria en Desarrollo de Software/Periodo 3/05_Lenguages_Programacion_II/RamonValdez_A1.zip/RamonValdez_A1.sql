SELECT * FROM Persona
SELECT * FROM Empleado
SELECT * FROM Puesto

CREATE TABLE [dbo].[Puesto](
    [ID_Puesto] [int] NOT NULL PRIMARY KEY,
	[Puesto] [nvarchar](30) NOT NULL,
	[Descripcion_Puesto] [nvarchar](30) NOT NULL,
	[Tipo_Puesto] [bit] NOT NULL,
	[Prestacion][nvarchar] (4) NOT NULL,
	[Prestacion_Puesto] [nvarchar] (15) NULL,
);
SET IDENTITY_INSERT dbo.Puesto ;
INSERT INTO dbo.Puesto(ID_Puesto,Puesto,Descripcion_Puesto,Tipo_Puesto,Prestacion,Prestacion_Puesto)
VALUES (1,'Gerente','Gerente Supervisor Depto. TDA',1,'Si','Combustible');
INSERT INTO dbo.Puesto(ID_Puesto,Puesto,Descripcion_Puesto,Tipo_Puesto,Prestacion,Prestacion_Puesto)
VALUES (2,'Vendedor','Vendedor Deptos. TDA',0,'No',null);
INSERT INTO dbo.Puesto(ID_Puesto,Puesto,Descripcion_Puesto,Tipo_Puesto,Prestacion,Prestacion_Puesto)
VALUES (3,'Cajero','Punto de Vta. TDA',0,'No',null);

SELECT * FROM  Centro
CREATE TABLE [dbo].[Centro](
	[Num_Centro] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[NombreC] [nvarchar](30) NOT NULL,
	[CiudadC] [nvarchar](30) NOT NULL,
);

SET IDENTITY_INSERT dbo.Centro on;
INSERT INTO dbo.Centro (Num_Centro,NombreC,CiudadC)
VALUES (2001,'Tienda La Primavera','Culiacan');
SET IDENTITY_INSERT dbo.Centro off;
INSERT INTO dbo.Centro (NombreC,CiudadC)
VALUES ('Tienda Humaya','Culiacan');
INSERT INTO dbo.Centro (NombreC,CiudadC)
VALUES ('Tienda Plaza Sur','Culiacan');
INSERT INTO dbo.Centro (NombreC,CiudadC)
VALUES ('Tienda Ruby','Culiacan');
INSERT INTO dbo.Centro (NombreC,CiudadC)
VALUES ('Tienda Obregon','Culiacan');


CREATE TABLE [dbo].[Persona](
	[ID] [int] IDENTITY(1,1) NOT NULL PRIMARY KEY,
	[Nombre] [nvarchar](15) NOT NULL,
	[ApellidoP] [nvarchar](20) NOT NULL,
	[ApellidoM] [nvarchar](20) NOT NULL,
	[RFC] [nvarchar](20) NOT NULL,
	[FechaN] [date] NOT NULL,
	[ID_Puesto] [int] NOT NULL,
	[Num_Centro] [int] NOT NULL,
);

ALTER TABLE [dbo].[Persona]  WITH CHECK ADD  CONSTRAINT [FK_Persona_Puesto] FOREIGN KEY([ID_Puesto])
REFERENCES [dbo].[Puesto] ([ID_Puesto])
GO
ALTER TABLE [dbo].[Persona]  WITH CHECK ADD  CONSTRAINT [FK_Persona_Centro] FOREIGN KEY([Num_Centro])
REFERENCES [dbo].[Centro] ([Num_Centro])
GO

SET IDENTITY_INSERT dbo.Persona on;
INSERT INTO dbo.Persona(ID,Nombre,ApellidoP,ApellidoM,RFC,FechaN,ID_Puesto,Num_Centro) 
VALUES (5001,'Juan','Castro','Castro','CACJ830604','1983-06-04',1,2001);
SET IDENTITY_INSERT dbo.Persona off;
INSERT INTO dbo.Persona(Nombre,ApellidoP,ApellidoM,RFC,FechaN,ID_Puesto,Num_Centro) 
VALUES ('Julian','Meza','Perez','MEPJ830605','1983-06-05',2,2002);
INSERT INTO dbo.Persona(Nombre,ApellidoP,ApellidoM,RFC,FechaN,ID_Puesto,Num_Centro) 
VALUES ('Carlos','Lopez','Garcia','LOGC830606','1983-06-06',3,2003);
INSERT INTO dbo.Persona(Nombre,ApellidoP,ApellidoM,RFC,FechaN,ID_Puesto,Num_Centro) 
VALUES ('Manuel','Lagos','Rosa','LARM830607','1983-06-07',1,2004);
INSERT INTO dbo.Persona(Nombre,ApellidoP,ApellidoM,RFC,FechaN,ID_Puesto,Num_Centro) 
VALUES ('Oscar','Rosa','Meza','ROMO830608','1983-06-08',3,2005);

select * from dbo.Persona
select * from dbo.Puesto
select * from dbo.centro

drop table [dbo].[puesto];
DELETE FROM Centro

select * from dbo.Puesto

select p1.*, p2.*, c.*
from Persona p1 LEFT JOIN Puesto p2 ON p1.ID_Puesto=p2.ID_Puesto
LEFT JOIN Centro C ON p1.Num_Centro=c.Num_Centro


select p1.ID, p1.Nombre, p1.ApellidoP, p1.ApellidoM, p1.RFC, p1.FechaN, p2.Puesto, p2.Descripcion_Puesto, p2.Tipo_Puesto, p2.Prestacion, p2.Prestacion_Puesto, c.Num_Centro, c.NombreC
from Persona p1 LEFT JOIN Puesto p2 ON p1.ID_Puesto=p2.ID_Puesto
LEFT JOIN Centro C ON p1.Num_Centro=c.Num_Centro
order by tipo_puesto desc


CREATE PROCEDURE dbo.UNI_A1
AS
BEGIN 

	WITH rep AS( select p1.ID, p1.Nombre, p1.ApellidoP, p1.ApellidoM, p1.RFC, p1.FechaN, p2.Puesto, p2.Descripcion_Puesto, p2.Tipo_Puesto, p2.Prestacion, p2.Prestacion_Puesto, c.Num_Centro, c.NombreC
from Persona p1 LEFT JOIN Puesto p2 ON p1.ID_Puesto=p2.ID_Puesto
LEFT JOIN Centro C ON p1.Num_Centro=c.Num_Centro)

	SELECT 	REPORT = 'DATABASE TABLES',
		ServerName = @@SERVERNAME,
		DatabaseName = DB_NAME(),
		*
	FROM rep
	ORDER BY 4, 5
END


EXEC [dbo].[UNI_A1]
GO

