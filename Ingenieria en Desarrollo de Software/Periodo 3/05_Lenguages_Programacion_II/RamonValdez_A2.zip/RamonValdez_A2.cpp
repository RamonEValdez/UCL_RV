// Polimorfismo1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//Actividad 2: Lenguajes de Programacion II
//IDS_REVF

#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

class Persona {
private:
    string Nombre;
    int Edad;
public:
    Persona(string, int);
    virtual void Mostrar();
};

class Alumno :public Persona {
private:
    float CalFinal;
    string Nivel;
public:
    Alumno(string, int, float, string);
    void Mostrar();
};

class Maestro :public Persona {
private:
    string Materia;
public:
    Maestro(string, int, string);
    void Mostrar();
};

class Rector :public Persona {
private:
    string Uni;
public:
    Rector(string, int, string);
    void Mostrar();
};

Persona::Persona(string _Nom, int _Edad) {
    Nombre = _Nom;
    Edad = _Edad;
 }

void Persona::Mostrar() {
    cout << "\tNombre: " << Nombre << endl;
    cout << "\tEdad: " << Edad << endl;
 }

Alumno::Alumno(string _Nom, int _Edad, float _CalFin, string _Nvl) : Persona(_Nom, _Edad) {
    CalFinal = _CalFin;
    Nivel = _Nvl;
 }

void Alumno::Mostrar() {
    Persona::Mostrar();
    cout << "\tCalificacion Final Alumno: " << CalFinal << endl;
    cout << "\tNivel Escolar: " << Nivel << endl;
 }

Maestro::Maestro(string _Nom, int _Edad, string _Materia) : Persona(_Nom, _Edad) {
    Materia = _Materia;
}

void Maestro::Mostrar() {
    Persona::Mostrar();
    cout << "\tMateria Impartida: " << Materia << endl;
}

Rector::Rector(string _Nom, int _Edad, string _Uni) : Persona(_Nom, _Edad) {
    Uni = _Uni;
}

void Rector::Mostrar() {
    Persona::Mostrar();
    cout << "\tRector de la univercidad: " << Uni << endl;
}

int main(){
    Persona* Vector[5];

    Vector[0] = new Alumno("Angela Duarte", 19, 80, "Primero Grado");
    Vector[1] = new Alumno("Toni Cocas", 21, 70,"Tercer Grado");
    Vector[2] = new Maestro("Jaime Zapata", 35, "Progrmacion C++");
    Vector[3] = new Rector("Dulce Lopez", 40, "UMI Coppel");
            
    Vector[0]->Mostrar();
    cout << "\n";
    Vector[1]->Mostrar();
    cout << "\n";
    Vector[2]->Mostrar();
    cout << "\n";
    Vector[3]->Mostrar();
    cout << "\n";
    

    system("pausa");
    return 0;
}
