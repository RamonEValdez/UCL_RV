package com.tda_sara.Tienda.Sara.Services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tda_sara.Tienda.Sara.Models.Category;

public interface CategoryRepo extends JpaRepository<Category, Integer>{
    
}