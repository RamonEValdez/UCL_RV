package com.tda_sara.Tienda.Sara.Services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tda_sara.Tienda.Sara.Models.Mark;

public interface MarkRepo extends JpaRepository<Mark, Integer>{
    
}