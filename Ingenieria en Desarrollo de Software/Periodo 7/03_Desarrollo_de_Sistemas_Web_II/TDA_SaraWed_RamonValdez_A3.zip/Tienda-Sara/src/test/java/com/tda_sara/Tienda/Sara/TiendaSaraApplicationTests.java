package com.tda_sara.Tienda.Sara;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaSaraApplicationTests {

	@Test
	void contextLoads() {
	}

}
