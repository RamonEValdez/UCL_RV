products = {
    computo: [
      { id: 'computo-1', name: 'Laptop Lenovo Gaming', image: 'assets/images/computo1.jpg', price: 20000, description: 'Laptop Gamer Lenovo LOQ 15ARP9 15.6 Pulgadas Windows 11 AMD Ryzen 5 NVIDIA GeForce RTX 3050 8 GB RAM 512 GB SSD Gri.' },
      { id: 'computo-2', name: 'Laptop DELL Gaming', image: 'assets/images/computo2.jpg', price: 24000, description: 'Laptop Dell Gaming G15 5530 CI5-13450HX 10 núcleos 16 GB 512 GB SSD RTX4050.' },
      { id: 'computo-3', name: 'Laptop ASUS Gaming', image: 'assets/images/computo3.jpg', price: 25000, description: 'ASUS Laptop ROG Strix G14/16 FHD+/Intel Core i7 13va/NVIDIA GeForce RTX4060/16GB RAM Expandible hasta 32GB/1TB SSD/Teclado Retroiluminado RGB 4.' },
    ],
    electronica: [
      { id: 'electronica-1', name: 'Smart TV Hisense', image: 'assets/images/electronica1.jpg', price: 11000, description: 'Smart TV con resolución 4K y tecnología HDR para imágenes vibrantes.' },
      { id: 'electronica-2', name: 'Smart TV Samsung', image: 'assets/images/electronica2.jpg', price: 10000, description: 'Smart TV con pantalla QLED y sonido envolvente para una experiencia cinematográfica.' },
      { id: 'electronica-3', name: 'Smart TV LG', image: 'assets/images/electronica3.jpg', price: 9500, description: 'Smart TV con tecnología OLED y colores perfectos para una visualización excepcional.' },
    ],
    moviles: [
      { id: 'moviles-1', name: 'Samsung Galaxy S24 Ultra', image: 'assets/images/moviles1.jpg', price: 28999, description: 'Smartphone con cámara de alta resolución y rendimiento potente.' },
      { id: 'moviles-2', name: 'Iphone 16 Pro Max', image: 'assets/images/moviles2_1.jpg', price: 40999, description: 'Smartphone con diseño elegante y funciones avanzadas.' },
      { id: 'moviles-3', name: 'Honor Magic 7 Pro', image: 'assets/images/moviles3.jpg', price: 24000, description: 'Smartphone con carga rápida y pantalla de alta frecuencia de actualización.' },
    ],
    ropa: [
      { id: 'ropa-1', name: 'Nike Sportwear', image: 'assets/images/ropa1.jpg', price: 1900, description: 'Ropa deportiva cómoda y duradera para tus entrenamientos.' },
      { id: 'ropa-2', name: 'Reebok Identity', image: 'assets/images/ropa2.jpg', price: 800, description: 'Ropa casual con estilo moderno y materiales de calidad.' },
      { id: 'ropa-3', name: 'Puma MMQ', image: 'assets/images/ropa3.jpg', price: 1250, description: 'Ropa urbana con diseño innovador y ajuste perfecto.' },
    ],
    zapatos: [
      { id: 'zapatos-1', name: 'Nike Dunk High Retro', image: 'assets/images/zapatos1.jpg', price: 2800, description: 'Zapatillas clásicas con estilo retro y comodidad excepcional.' },
      { id: 'zapatos-2', name: 'Reebok Royal Hi 2', image: 'assets/images/zapatos2.jpg', price: 1950, description: 'Zapatillas de caña alta con diseño urbano y soporte adicional.' },
      { id: 'zapatos-3', name: 'Puma RBD Game', image: 'assets/images/zapatos3.jpg', price: 1500, description: 'Botas deportivas con estilo moderno y tracción superior.' },
    ],
  };