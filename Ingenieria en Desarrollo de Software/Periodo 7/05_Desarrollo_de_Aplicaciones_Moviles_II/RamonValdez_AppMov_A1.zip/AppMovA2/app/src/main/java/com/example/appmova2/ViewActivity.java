package com.example.appmova2;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewActivity extends AppCompatActivity {

    Button play1, play2, play3, play4, play5, play6;
    MediaPlayer mp1, mp2, mp3, mp4, mp5, mp6;

   @Override
    protected void onCreate(Bundle savedInstatnceState) {
        super.onCreate(savedInstatnceState);
        setContentView(R.layout.activity_view);

        play1 = (Button)findViewById(R.id.play1);
        play2 = (Button)findViewById(R.id.play2);
        play3 = (Button)findViewById(R.id.play3);
        play4 = (Button)findViewById(R.id.play4);
        play5 = (Button)findViewById(R.id.play5);
        play6 = (Button)findViewById(R.id.play6);

        mp1 = MediaPlayer.create(this, R.raw.seg);
        mp2 = MediaPlayer.create(this, R.raw.duckhunt);
        mp3 = MediaPlayer.create(this, R.raw.starwars);
        mp4 = MediaPlayer.create(this, R.raw.xman);
        mp5 = MediaPlayer.create(this, R.raw.thundercats);
        mp6 = MediaPlayer.create(this, R.raw.munra);

        play1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                if(mp1.isPlaying()){
                   mp1.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                    mp1.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
        });

       play2.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp2.isPlaying()){
                   mp2.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp2.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play3.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp3.isPlaying()){
                   mp3.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp3.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play4.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp4.isPlaying()){
                   mp4.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp4.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play5.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp5.isPlaying()){
                   mp5.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp5.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play6.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp6.isPlaying()){
                   mp6.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp6.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });
    }
}








