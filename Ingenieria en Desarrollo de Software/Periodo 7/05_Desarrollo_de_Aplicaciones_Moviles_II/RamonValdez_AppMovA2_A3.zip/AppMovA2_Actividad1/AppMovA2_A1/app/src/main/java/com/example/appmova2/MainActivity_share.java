package com.example.appmova2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity_share extends AppCompatActivity {

        Button fcb, twit, what, insta, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_share);
        fcb = (Button) findViewById(R.id.fcb);
        twit = (Button) findViewById(R.id.twit);
        what = (Button) findViewById(R.id.what);
        insta = (Button) findViewById(R.id.insta);
        back = (Button) findViewById(R.id.back);

        fcb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra la mejor variedad de sonidos aqui con nosotros.");
                share.setPackage("com.facebook.katana");
                startActivity(Intent.createChooser(share, "Compartir"));
            }
        });

        twit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra la mejor variedad de sonidos aqui con nosotros.");
                share.setPackage("com.twitter.android");
                startActivity(Intent.createChooser(share, "Compartir"));
            }
        });

        what.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra la mejor variedad de sonidos aqui con nosotros.");
                share.setPackage("com.whatsapp");
                startActivity(Intent.createChooser(share, "Compartir"));
            }
        });

        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra la mejor variedad de sonidos aqui con nosotros.");
                share.setPackage("com.instagram.android");
                startActivity(Intent.createChooser(share, "Compartir"));
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity_share.this, ViewActivity.class);
                startActivity(i);
            }
        });
    }

}