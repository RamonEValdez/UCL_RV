package com.example.appmova2;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewActivity extends AppCompatActivity {

    Button play1, play2, play3, play4, play5, play6;

    Button share1, share2, share3, share4, share5, share6;
    Button blu1, blu2, blu3, blu4, blu5, blu6;
    MediaPlayer mp1, mp2, mp3, mp4, mp5, mp6;

   @Override
    protected void onCreate(Bundle savedInstatnceState) {
        super.onCreate(savedInstatnceState);
        setContentView(R.layout.activity_view);

        play1 = (Button)findViewById(R.id.play1);
        play2 = (Button)findViewById(R.id.play2);
        play3 = (Button)findViewById(R.id.play3);
        play4 = (Button)findViewById(R.id.play4);
        play5 = (Button)findViewById(R.id.play5);
        play6 = (Button)findViewById(R.id.play6);

       share1 = findViewById(R.id.share1);
       share2 = findViewById(R.id.share2);
       share3 = findViewById(R.id.share3);
       share4 = findViewById(R.id.share4);
       share5 = findViewById(R.id.share5);
       share6 = findViewById(R.id.share6);

       blu1 = findViewById(R.id.blu1);
       blu2 = findViewById(R.id.blu2);
       blu3 = findViewById(R.id.blu3);
       blu4 = findViewById(R.id.blu4);
       blu5 = findViewById(R.id.blu5);
       blu6 = findViewById(R.id.blu6);

        mp1 = MediaPlayer.create(this, R.raw.seg);
        mp2 = MediaPlayer.create(this, R.raw.knight_);
        mp3 = MediaPlayer.create(this, R.raw.starwars);
        mp4 = MediaPlayer.create(this, R.raw.xman);
        mp5 = MediaPlayer.create(this, R.raw.thundercats);
        mp6 = MediaPlayer.create(this, R.raw.munra);

        play1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                if(mp1.isPlaying()){
                   mp1.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                    mp1.start();
                    Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
        });

       play2.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp2.isPlaying()){
                   mp2.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp2.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play3.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp3.isPlaying()){
                   mp3.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp3.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play4.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp4.isPlaying()){
                   mp4.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp4.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play5.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp5.isPlaying()){
                   mp5.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp5.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       play6.setOnClickListener(new View.OnClickListener(){

           public void onClick(View v) {
               if(mp6.isPlaying()){
                   mp6.pause();
                   Toast.makeText(ViewActivity.this, "Pausa", Toast.LENGTH_SHORT).show();
               }else{
                   mp6.start();
                   Toast.makeText(ViewActivity.this, "Play", Toast.LENGTH_SHORT).show();
               }
           }
       });

       share1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(ViewActivity.this, MainActivity_share.class);
               startActivity(i);
           }
       });

       share2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(ViewActivity.this, MainActivity_share.class);
               startActivity(i);
           }
       });

       share3.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(ViewActivity.this, MainActivity_share.class);
               startActivity(i);
           }
       });

       share4.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(ViewActivity.this, MainActivity_share.class);
               startActivity(i);
           }
       });

       share5.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(ViewActivity.this, MainActivity_share.class);
               startActivity(i);
           }
       });

       share6.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i = new Intent(ViewActivity.this, MainActivity_share.class);
               startActivity(i);
           }
       });

       blu1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
               alerta.setMessage("Has compartido por medio de Blutooth el tono: Gone In 60 Seconds-Flower felicidades..")
                       .setCancelable(false)
                       .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               finish();
                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               dialog.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("FELICIDADES");
               titulo.show();
           }
       });

       blu2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
               alerta.setMessage("Has compartido por medio de Blutooth el tono: Knight Rider felicidades..")
                       .setCancelable(false)
                       .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               finish();
                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               dialog.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("FELICIDADES");
               titulo.show();
           }
       });

       blu3.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
               alerta.setMessage("Has compartido por medio de Blutooth el tono: Star Wars R2-D2 felicidades..")
                       .setCancelable(false)
                       .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               finish();
                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               dialog.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("FELICIDADES");
               titulo.show();
           }
       });

       blu4.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
               alerta.setMessage("Has compartido por medio de Blutooth el tono: X-MAN felicidades..")
                       .setCancelable(false)
                       .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               finish();
                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               dialog.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("FELICIDADES");
               titulo.show();
           }
       });

       blu5.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
               alerta.setMessage("Has compartido por medio de Blutooth el tono: Thundecats felicidades..")
                       .setCancelable(false)
                       .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               finish();
                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               dialog.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("FELICIDADES");
               titulo.show();
           }
       });

       blu6.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               AlertDialog.Builder alerta = new AlertDialog.Builder(ViewActivity.this);
               alerta.setMessage("Has compartido por medio de Blutooth el tono: Thundecats - Munra felicidades..")
                       .setCancelable(false)
                       .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               finish();
                           }
                       })
                       .setNegativeButton("No", new DialogInterface.OnClickListener() {
                           @Override
                           public void onClick(DialogInterface dialog, int which) {
                               dialog.cancel();
                           }
                       });
               AlertDialog titulo = alerta.create();
               titulo.setTitle("FELICIDADES");
               titulo.show();
           }
       });
    }
}








